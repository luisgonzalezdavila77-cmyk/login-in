# 📈 Diagramas y Flujos Visuales

## 1. Arquitectura del Sistema

```
┌─────────────────────────────────────────────────────────────┐
│                    NAVEGADOR DEL USUARIO                    │
│                    (localhost:5173)                          │
│                                                              │
│  ┌──────────────────────────────────────────────────────┐  │
│  │              VUE DE USUARIO (HTML)                   │  │
│  │  - registerView.js (Formulario registro)            │  │
│  │  - loginView.js (Formulario login)                  │  │
│  │  - homeView.js (Dashboard)                          │  │
│  └──────────────────────────────────────────────────────┘  │
│                           ↑ ↓                                │
│  ┌──────────────────────────────────────────────────────┐  │
│  │           CONTROLADORES (Lógica)                     │  │
│  │  - registerController.js                            │  │
│  │  - loginController.js                               │  │
│  │  - homeController.js                                │  │
│  └──────────────────────────────────────────────────────┘  │
│                           ↑ ↓                                │
│  ┌──────────────────────────────────────────────────────┐  │
│  │         COMPONENTES (Partes reutilizables)           │  │
│  │  - UserManagement.js                                │  │
│  │  - ReservationCard.js                               │  │
│  │  - AdminDashboard.js                                │  │
│  └──────────────────────────────────────────────────────┘  │
│                           ↑ ↓                                │
│  ┌──────────────────────────────────────────────────────┐  │
│  │              HTTP CLIENT (http.js)                   │  │
│  │  GET / POST / DELETE                                │  │
│  └──────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────┘
           ↑ ↓ (Comunicación HTTP/JSON)
┌─────────────────────────────────────────────────────────────┐
│              SERVIDOR JSON-SERVER                           │
│              (localhost:3001)                               │
│                                                              │
│  ┌──────────────────────────────────────────────────────┐  │
│  │              BASE DE DATOS (db.json)                 │  │
│  │  • Tabla: users (usuarios registrados)              │  │
│  │  • Tabla: reservations (reservas)                   │  │
│  └──────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────┘
```

---

## 2. Flujo de Registro Completo

```
START: Usuario quiere registrarse
│
├─ 1. Usuario navega a /register
│     └─ registerView() se carga
│
├─ 2. registerView muestra formulario
│     Campos: [Nombre] [Email] [Contraseña] [Confirmar]
│
├─ 3. Usuario llena datos y presiona "Create Account"
│
├─ 4. registerController() se ejecuta:
│     │
│     ├─ Obtiene datos del formulario
│     │   {name, email, password, confirmPassword}
│     │
│     ├─ Validación 1: ¿Campos completos?
│     │   NO → Muestra "Todos los campos son requeridos" → FIN
│     │   SÍ → Continúa
│     │
│     ├─ Validación 2: ¿Passwords iguales?
│     │   NO → Muestra "Las contraseñas no coinciden" → FIN
│     │   SÍ → Continúa
│     │
│     ├─ Validación 3: ¿Password >= 6 caracteres?
│     │   NO → Muestra "Mínimo 6 caracteres" → FIN
│     │   SÍ → Continúa
│     │
│     ├─ Validación 4: ¿Email ya existe?
│     │   http.get("/users") → obtiene lista
│     │   Busca si email existe
│     │   SÍ → Muestra "Email ya registrado" → FIN
│     │   NO → Continúa
│     │
│     └─ Validaciones OK → Crear usuario
│
├─ 5. Crear objeto newUser:
│     {
│       id: "1717605234567" (timestamp),
│       name: "Juan Pérez",
│       email: "juan@example.com",
│       password: "A123456",
│       role: "user"
│     }
│
├─ 6. Guardar en base de datos:
│     http.post("/users", newUser)
│     └─ Servidor recibe y guarda en db.json
│
├─ 7. ¡Éxito!
│     Muestra: "¡Cuenta creada! Ahora puedes login"
│
└─ 8. Redirige a /login
    └─ navigateTo("/login")

END: Usuario puede iniciar sesión
```

---

## 3. Flujo de Gestión de Usuarios

```
START: Admin quiere ver y eliminar usuarios
│
├─ 1. Admin navega a /home
│     └─ homeView() se carga
│
├─ 2. homeView() detecta que es admin
│     └─ Incluye UserManagement component
│
├─ 3. UserManagement.js se ejecuta:
│     │
│     ├─ http.get("/users")
│     │  └─ Obtiene lista completa de usuarios
│     │
│     ├─ Filter para excluir admin@test.com
│     │
│     └─ Genera tabla HTML con botones "Remove"
│
├─ 4. Admin ve tabla con todos los usuarios:
│     ┌────────────────────────────────┐
│     │ ID │ Nombre │ Email │ Remove   │
│     ├────────────────────────────────┤
│     │ 1  │ Juan   │ j@... │ [Remove] │
│     │ 2  │ María  │ m@... │ [Remove] │
│     └────────────────────────────────┘
│
├─ 5. Admin presiona botón "Remove" de un usuario
│
├─ 6. setupDeleteUserButtons() se ejecuta:
│     │
│     ├─ Se activa event listener del botón
│     │
│     ├─ Pregunta confirmación:
│     │  "¿Seguro que quieres eliminar a juan@example.com?"
│     │  [OK] [Cancelar]
│     │
│     ├─ Admin presiona [OK]
│     │
│     └─ Procede a eliminar
│
├─ 7. Enviar petición DELETE:
│     http.delete("/users/1")
│     └─ Servidor elimina usuario de db.json
│
├─ 8. Recargar tabla:
│     homeController() se ejecuta de nuevo
│     └─ UserManagement() obtiene lista actualizada
│
└─ 9. Tabla se actualiza sin ese usuario
    └─ Usuario eliminado ✓

END: Usuario eliminado del sistema
```

---

## 4. Flujo de Login

```
START: Usuario quiere iniciar sesión
│
├─ 1. Usuario va a /login
│     └─ loginView() muestra formulario
│
├─ 2. Usuario entra:
│     Email: [admin@test.com]
│     Password: [A123456]
│
├─ 3. Presiona "Sign In"
│     └─ loginController() se ejecuta
│
├─ 4. Obtiene datos del formulario:
│     {email, password}
│
├─ 5. Busca en base de datos:
│     http.get("/users")
│     └─ Trae todos los usuarios
│
├─ 6. Busca usuario con ese email:
│     const user = users.find(u => u.email === email)
│     │
│     ├─ ¿Encontrado?
│     │   NO → Muestra "Email no encontrado" → FIN
│     │   SÍ → Continúa
│     │
│     └─ ¿Contraseña correcta?
│         NO → Muestra "Contraseña incorrecta" → FIN
│         SÍ → Continúa
│
├─ 7. ¡TODO CORRECTO!
│     Guarda usuario en localStorage:
│     localStorage.setItem("user", JSON.stringify(user))
│     └─ Guarda: {id, name, email, role}
│
├─ 8. Redirige a /home:
│     navigateTo("/home")
│
└─ 9. Usuario logeado en el dashboard

END: Sesión iniciada
```

---

## 5. Verificación de Autenticación

```
Usuario navega a URL
│
├─ router() se ejecuta
│
├─ Lee la URL:
│  ├─ /register  → Ruta pública (no necesita login)
│  ├─ /login     → Ruta pública (no necesita login)
│  ├─ /home      → Ruta PROTEGIDA (necesita login)
│  └─ /404       → Ruta 404
│
├─ Verifica autenticación:
│  const isAuthenticated = !!localStorage.getItem("user")
│  │
│  ├─ ¿Es ruta pública?
│  │   SÍ → Muestra la vista
│  │   NO → Continúa
│  │
│  ├─ ¿Usuario está logeado?
│  │   SÍ → Muestra la vista
│  │   NO → Redirige a /login
│  │
│  └─ ¿Ruta existe?
│      SÍ → Muestra la vista
│      NO → Muestra página 404
│
└─ Renderiza la vista correcta
```

---

## 6. Estructura de Datos - Usuarios

```
Usuario en db.json:
{
  "id": "1717605234567",           ← ID único (basado en timestamp)
  "name": "Juan Pérez",            ← Nombre completo
  "email": "juan@example.com",     ← Email (ÚNICO, no se repite)
  "password": "A123456",           ← Contraseña (guardada en texto plano)
  "role": "user"                   ← Rol: "user" o "admin"
}

Usuario en localStorage (cuando inicia sesión):
{
  "id": "1717605234567",
  "name": "Juan Pérez",
  "email": "juan@example.com",
  "role": "user"
}
```

---

## 7. Estructura de Datos - Reservas

```
Reserva en db.json:
{
  "id": "1",                      ← ID único
  "userId": "1",                  ← Quién la hizo
  "workspace": "Oficina 1",       ← Cuál espacio
  "date": "2026-06-10",           ← Qué fecha
  "startHour": "09:00",           ← Hora inicio
  "endHour": "12:00",             ← Hora fin
  "reason": "Reunión con cliente",← Para qué
  "status": "pending",            ← pending/approved/rejected
  "spaceType": "oficina",         ← Tipo: oficina/coworking/sala/auditorio
  "price": "290.000"              ← Precio por día
}
```

---

## 8. Ciclo de Vida de una Página

```
1. Usuario navega a /register
   ↓
2. router() lee la URL
   ↓
3. Se llama registerView()
   ↓
4. registerView retorna HTML
   ↓
5. HTML se inserta en el DOM (#app)
   ↓
6. setTimeout(() => { registerController(); })
   ↓
7. registerController() busca #registerForm
   ↓
8. Agrega event listener al formulario
   ↓
9. Usuario ve la página y puede interactuar
   ↓
10. Usuario presiona botón
    ↓
11. registerController() se ejecuta (validaciones)
    ↓
12. Si todo está bien → http.post() envía datos
    ↓
13. Servidor responde OK
    ↓
14. navigateTo("/login") cambia la URL
    ↓
15. Vuelve al paso 2 para cargar /login
```

---

## 9. Peticiones HTTP

### POST - Crear usuario

```
Navegador (Cliente)                  Servidor
    │                                   │
    ├──── POST /users ────────────────→ │
    │     {                             │
    │       name: "Juan",               │
    │       email: "j@test.com",        │
    │       password: "A123456",        │
    │       role: "user"                │
    │     }                             │
    │                                   │ Guardar en db.json
    │                  ←─── 201 OK ─── │
    │                    Usuario creado │
    │                                   │
```

### GET - Obtener usuarios

```
Navegador (Cliente)                  Servidor
    │                                   │
    ├──── GET /users ─────────────────→ │
    │                                   │
    │                  ←─── 200 OK ─── │
    │                    [              │
    │                      {id, name...}│
    │                      {id, name...}│
    │                    ]              │
    │                                   │
```

### DELETE - Eliminar usuario

```
Navegador (Cliente)                  Servidor
    │                                   │
    ├──── DELETE /users/1 ────────────→ │
    │                                   │
    │                  ←─── 200 OK ─── │
    │                   Usuario borrado │
    │                                   │
```

---

## 10. Diferencia entre Usuario y Admin

```
USUARIO NORMAL                      ADMIN
├─ Ve solo sus reservas           ├─ Ve TODAS las reservas
├─ Puede crear reserva            ├─ Puede crear reserva
├─ Puede editar sus propias        ├─ Puede editar CUALQUIER
│  reservas                        │  reserva
├─ NO ve panel de usuarios        ├─ Ve tabla de USUARIOS
├─ NO puede aprobar/rechazar      ├─ Puede aprobar/rechazar
├─ NO puede eliminar usuarios     ├─ Puede eliminar usuarios
└─ role = "user"                  └─ role = "admin"
```

---

## 11. Estado de Reserva

```
Ciclo de vida de una reserva:

1. PENDING (Pendiente)
   └─ Usuario crea reserva
   └─ Admin la ve, puede:
      ├─ Aprobar → status = "approved"
      └─ Rechazar → status = "rejected"

2. APPROVED (Aprobada)
   └─ Admin la aprobó
   └─ Aparece confirmada
   └─ Usuario puede cancelar

3. REJECTED (Rechazada)
   └─ Admin la rechazó
   └─ Usuario ve que fue rechazada
   └─ Puede crear nueva

4. CANCELLED (Cancelada)
   └─ Usuario canceló una aprobada
   └─ Ya no cuenta como reserva
```

---

## 12. Flujo completo Usuario Normal

```
┌─────────────────────────────────────────┐
│ 1. Usuario va a localhost:5173          │
├─────────────────────────────────────────┤
│ 2. Ve página de login                   │
├─────────────────────────────────────────┤
│ 3. Clica "Create one" → Va a /register  │
├─────────────────────────────────────────┤
│ 4. Llena formulario y presiona crear    │
├─────────────────────────────────────────┤
│ 5. Se validan datos                     │
├─────────────────────────────────────────┤
│ 6. Se guarda en db.json                 │
├─────────────────────────────────────────┤
│ 7. Se redirige a /login                 │
├─────────────────────────────────────────┤
│ 8. Entra email y contraseña nuevas      │
├─────────────────────────────────────────┤
│ 9. Valida contra db.json                │
├─────────────────────────────────────────┤
│ 10. Se guarda sesión en localStorage    │
├─────────────────────────────────────────┤
│ 11. Va a /home (dashboard)              │
├─────────────────────────────────────────┤
│ 12. Ve sus reservas                     │
├─────────────────────────────────────────┤
│ 13. Clica "+ Nueva Reserva"             │
├─────────────────────────────────────────┤
│ 14. Llena formulario de reserva         │
├─────────────────────────────────────────┤
│ 15. Presiona "Crear Reserva"            │
├─────────────────────────────────────────┤
│ 16. Se guarda en db.json (status pending)│
├─────────────────────────────────────────┤
│ 17. Usuario ve su reserva (pendiente)   │
├─────────────────────────────────────────┤
│ 18. Espera que admin la apruebe         │
├─────────────────────────────────────────┤
│ 19. Admin ve en dashboard, presiona OK  │
├─────────────────────────────────────────┤
│ 20. status = "approved"                 │
├─────────────────────────────────────────┤
│ 21. Usuario ve reserva como aprobada    │
└─────────────────────────────────────────┘
```

---

## 13. Flujo completo Admin

```
┌──────────────────────────────────────────┐
│ 1. Admin inicia sesión con             │
│    admin@test.com / A123456            │
├──────────────────────────────────────────┤
│ 2. Va a /home (dashboard admin)        │
├──────────────────────────────────────────┤
│ 3. Ve:                                 │
│    ├─ Panel de Administrador           │
│    ├─ Dashboard con estadísticas       │
│    ├─ Tabla de usuarios registrados    │
│    └─ Todas las reservas del sistema   │
├──────────────────────────────────────────┤
│ 4. Ver usuarios: Scroll "Registered Users"
├──────────────────────────────────────────┤
│ 5. Puede presionar "Remove" para        │
│    eliminar un usuario                 │
├──────────────────────────────────────────┤
│ 6. Debe confirmar eliminación          │
├──────────────────────────────────────────┤
│ 7. Usuario eliminado de db.json        │
├──────────────────────────────────────────┤
│ 8. Tabla se actualiza automáticamente  │
├──────────────────────────────────────────┤
│ 9. Ver reservas pendientes             │
├──────────────────────────────────────────┤
│ 10. Presiona "Aprobar" o "Rechazar"    │
├──────────────────────────────────────────┤
│ 11. status se actualiza en db.json     │
├──────────────────────────────────────────┤
│ 12. Reserva se muestra actualizada     │
├──────────────────────────────────────────┤
│ 13. Ver estadísticas:                  │
│    ├─ Salas Reservadas: X              │
│    ├─ Dinero que entró: $X             │
│    ├─ Solicitudes Pendientes: X        │
│    └─ Salas Disponibles: X             │
└──────────────────────────────────────────┘
```

---

## 14. Manejo de Errores

```
Error → Acción

Input vacío
    └─ Muestra: "Todos los campos son requeridos"

Email inválido
    └─ HTML5 valida automáticamente

Email ya existe
    └─ Muestra: "Email ya registrado"

Contraseñas no coinciden
    └─ Muestra: "Las contraseñas no coinciden"

Contraseña muy corta
    └─ Muestra: "Mínimo 6 caracteres"

Usuario no existe
    └─ Muestra: "Email no encontrado"

Contraseña incorrecta
    └─ Muestra: "Contraseña incorrecta"

Error de servidor
    └─ Muestra: "Error en la conexión"
    └─ Revisa browser console (F12)
```

---

## 15. LocalStorage

```
Qué se guarda en el navegador:

localStorage = {
  "user": "{\"id\":\"1\",\"name\":\"Juan\",\"email\":\"j@test.com\",\"role\":\"user\"}"
}

Para acceder:
const user = JSON.parse(localStorage.getItem("user"));
// Resultado: {id, name, email, role}

Para eliminar (logout):
localStorage.removeItem("user");
```

---

**¡Ya entiendes todos los flujos y diagramas!** 🎉

