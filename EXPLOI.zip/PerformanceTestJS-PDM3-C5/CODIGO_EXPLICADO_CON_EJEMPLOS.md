# 💻 Código Explicado con Ejemplos Paso a Paso

## Parte 1: El Registro de Usuario

### ¿Qué pasa cuando un usuario quiere registrarse?

---

## 📋 Paso 1: La Vista (registerView.js)

### Lo que ve el usuario:

```
┌──────────────────────────────────────────┐
│                                          │
│    LGC Reserva de Oficinas               │
│    Create a new account                  │
│                                          │
│    Full Name     [Juan Pérez          ]  │
│    Email         [juan@example.com    ]  │
│    Password      [••••••••••••••••    ]  │
│    Confirm Pwd   [••••••••••••••••    ]  │
│                                          │
│    [Create Account]                      │
│                                          │
│    Already have an account? Sign in      │
│                                          │
└──────────────────────────────────────────┘
```

### El código del formulario:

```javascript
// src/views/registerView.js

export default function registerView() {
  // Esto se ejecuta cuando cargas la página
  setTimeout(() => {
    registerController();  // Agrega eventos a los botones
  });

  // Retorna el HTML que ves en pantalla
  return `
    <form id="registerForm">
      
      <input 
        type="text" 
        id="name"
        name="name"
        placeholder="John Doe"
        required  // Campo obligatorio
      >
      
      <input 
        type="email" 
        id="email"
        name="email"
        placeholder="your@email.com"
        required
      >
      
      <input 
        type="password" 
        id="password"
        name="password"
        minlength="6"  // Mínimo 6 caracteres
        required
      >
      
      <input 
        type="password" 
        id="confirmPassword"
        name="confirmPassword"
        minlength="6"
        required
      >
      
      <button type="submit">Create Account</button>
      
    </form>
  `;
}
```

**¿Qué significa cada parte?**

| Código | Significa |
|--------|-----------|
| `type="text"` | Campo de texto normal |
| `type="email"` | Campo que valida que sea email |
| `type="password"` | Campo que oculta lo que escribes |
| `required` | No puedes enviar si está vacío |
| `minlength="6"` | Mínimo 6 caracteres |
| `<form id="registerForm">` | El formulario tiene ID para encontrarlo después |

---

## 🧠 Paso 2: El Controlador (registerController.js)

### Qué pasa cuando presionas "Create Account":

```javascript
// src/controllers/register.controller.js

export const registerController = () => {
  // 1. ENCONTRAR EL FORMULARIO EN LA PÁGINA
  const registerForm = document.querySelector("#registerForm");

  // 2. AGREGAR EVENT LISTENER (escuchar cuando presionas botón)
  if (registerForm) {
    registerForm.addEventListener("submit", async (e) => {
      e.preventDefault();  // No recarga la página
      
      // ========================================
      // 3. OBTENER DATOS DEL FORMULARIO
      // ========================================
      const formData = new FormData(registerForm);
      const data = Object.fromEntries(formData);
      
      // Resultado:
      // {
      //   name: "Juan Pérez",
      //   email: "juan@example.com",
      //   password: "A123456",
      //   confirmPassword: "A123456"
      // }
      
      // ========================================
      // 4. VALIDACIONES (verificar que esté todo bien)
      // ========================================
      
      // Validación 1: ¿Están todos los campos llenos?
      if (!data.name || !data.email || !data.password || !data.confirmPassword) {
        alert("All fields are required");
        return;  // Detiene aquí si falta algo
      }
      
      // Validación 2: ¿Las contraseñas son iguales?
      if (data.password !== data.confirmPassword) {
        alert("Passwords do not match");
        return;
      }
      
      // Validación 3: ¿Contraseña tiene 6+ caracteres?
      if (data.password.length < 6) {
        alert("Password must be at least 6 characters");
        return;
      }
      
      // ========================================
      // 5. VERIFICAR SI EL EMAIL YA EXISTE
      // ========================================
      try {
        // Obtiene TODOS los usuarios de la base de datos
        const users = await http.get("/users");
        
        // Busca si existe alguien con ese email
        const emailExists = users.some(
          (user) => user.email === data.email
        );
        
        // Si el email ya existe, muestra error
        if (emailExists) {
          alert("Email already registered. Try with a different email or sign in.");
          return;
        }
        
        // ========================================
        // 6. CREAR NUEVO USUARIO
        // ========================================
        const newUser = {
          id: Date.now().toString(),  // ID único
          name: data.name,
          email: data.email,
          password: data.password,
          role: "user"  // Siempre "user", nunca "admin"
        };
        
        // Resultado:
        // {
        //   id: "1717605234567",
        //   name: "Juan Pérez",
        //   email: "juan@example.com",
        //   password: "A123456",
        //   role: "user"
        // }
        
        // ========================================
        // 7. GUARDAR EN LA BASE DE DATOS
        // ========================================
        await http.post("/users", newUser);
        // Esto envía una petición HTTP POST a:
        // http://localhost:3001/users
        // Con los datos del usuario
        
        // ========================================
        // 8. MOSTRAR ÉXITO Y REDIRIGIR
        // ========================================
        alert("Account created successfully! You can now sign in.");
        navigateTo("/login");  // Lleva a la página de login
        
      } catch (error) {
        // Si algo sale mal (error de conexión, etc)
        console.error(error);
        alert("Error creating account. Please try again.");
      }
    });
  }
};
```

### Flujo Visual:

```
┌─────────────────────────────────────────┐
│ Usuario presiona "Create Account"       │
└─────────────────────────────────────────┘
                    ↓
        ┌───────────────────────┐
        │ Obtener datos form    │
        │ {name, email, pass}   │
        └───────────────────────┘
                    ↓
        ┌───────────────────────┐
        │ ¿Campos llenos?       │
        │ NO → Muestra error    │
        │ SÍ → Continúa         │
        └───────────────────────┘
                    ↓
        ┌───────────────────────┐
        │ ¿Pass = Confirm?      │
        │ NO → Muestra error    │
        │ SÍ → Continúa         │
        └───────────────────────┘
                    ↓
        ┌───────────────────────┐
        │ ¿Pass >= 6 chars?     │
        │ NO → Muestra error    │
        │ SÍ → Continúa         │
        └───────────────────────┘
                    ↓
        ┌───────────────────────┐
        │ Obtener usuarios      │
        │ GET /users            │
        └───────────────────────┘
                    ↓
        ┌───────────────────────┐
        │ ¿Email ya existe?     │
        │ SÍ → Muestra error    │
        │ NO → Continúa         │
        └───────────────────────┘
                    ↓
        ┌───────────────────────┐
        │ Crear usuario         │
        │ POST /users           │
        └───────────────────────┘
                    ↓
        ┌───────────────────────┐
        │ ¡Éxito!               │
        │ Ir a /login           │
        └───────────────────────┘
```

---

## 🌐 Paso 3: Comunicación con la Base de Datos (http.js)

```javascript
// src/api/http.js

export const http = {
  // GET - Obtener datos
  async get(endpoint) {
    const response = await fetch(`http://localhost:3001${endpoint}`);
    return await response.json();
  },
  
  // POST - Enviar datos nuevos
  async post(endpoint, data) {
    const response = await fetch(`http://localhost:3001${endpoint}`, {
      method: "POST",           // Tipo de petición
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify(data)  // Los datos en formato JSON
    });
    return await response.json();
  },
  
  // DELETE - Eliminar datos
  async delete(endpoint) {
    const response = await fetch(`http://localhost:3001${endpoint}`, {
      method: "DELETE"  // Tipo de petición
    });
    return await response.json();
  }
};
```

### Ejemplo:

```javascript
// Cuando registras un usuario:
const newUser = {
  id: "1717605234567",
  name: "Juan",
  email: "juan@example.com",
  password: "A123456",
  role: "user"
};

await http.post("/users", newUser);

// Se envía una petición HTTP:
// POST http://localhost:3001/users
// Body: {id, name, email, password, role}
// 
// El servidor (json-server) lo recibe y:
// 1. Agrega a db.json
// 2. Responde "OK"
```

---

## 👥 Parte 2: Gestión de Usuarios

### ¿Qué pasa cuando el admin quiere ver y eliminar usuarios?

---

## 📊 Paso 1: Vista de Usuarios (UserManagement.js)

```javascript
// src/components/UserManagement.js

export default async function UserManagement() {
  try {
    // 1. OBTENER TODOS LOS USUARIOS
    const users = await http.get("/users");
    // Resultado: [ {id, name, email, role}, ... ]
    
    // 2. FILTRAR (excluir admin de prueba)
    const managedUsers = users.filter(
      (u) => u.email !== "admin@test.com"
    );
    
    // 3. CREAR HTML DE LA TABLA
    return `
      <section>
        <h2>Registered Users</h2>
        
        <table>
          <thead>
            <tr>
              <th>ID</th>
              <th>Name</th>
              <th>Email</th>
              <th>Role</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          
          <tbody>
            ${managedUsers.map((user) => `
              <tr>
                <td>${user.id}</td>
                <td>${user.name}</td>
                <td>${user.email}</td>
                <td>${user.role === "admin" ? "Administrator" : "User"}</td>
                <td>Active</td>
                <td>
                  <button 
                    class="data-remove-user"
                    data-user-id="${user.id}"
                    data-user-email="${user.email}"
                  >
                    Remove
                  </button>
                </td>
              </tr>
            `).join("")}
          </tbody>
        </table>
        
        <div>
          <p><strong>Total Users:</strong> ${managedUsers.length}</p>
          <p><strong>Administrators:</strong> ${users.filter(u => u.role === "admin").length}</p>
        </div>
      </section>
    `;
    
  } catch (error) {
    console.error(error);
    return `<div>Error loading users</div>`;
  }
}
```

### Lo que ves en pantalla:

```
┌─────────────────────────────────────────────────────────┐
│ Registered Users                                        │
│                                                         │
│ ID  │ Name      │ Email           │ Role │ Remove      │
├─────┼───────────┼─────────────────┼──────┼─────────────┤
│ 1   │ Juan      │ juan@test.com   │ User │ [Remove]    │
│ 2   │ María     │ maria@test.com  │ User │ [Remove]    │
│ 3   │ Pedro     │ pedro@test.com  │ User │ [Remove]    │
└─────────────────────────────────────────────────────────┘

Total Users: 3
Administrators: 1
```

---

## 🗑️ Paso 2: Eliminar Usuario (home.controller.js)

```javascript
// src/controllers/home.controller.js

const setupDeleteUserButtons = () => {
  // 1. BUSCAR TODOS LOS BOTONES "Remove" 
  document
    .querySelectorAll("[data-remove-user]")
    .forEach((btn) => {
      // Hacer clone para evitar duplicados
      const newBtn = btn.cloneNode(true);
      btn.parentNode.replaceChild(newBtn, btn);
      
      // 2. AGREGAR EVENTO DE CLIC
      newBtn.addEventListener("click", async (e) => {
        e.preventDefault();
        
        // 3. OBTENER DATOS DEL USUARIO
        const userId = newBtn.dataset.userId;        // "1"
        const userEmail = newBtn.dataset.userEmail;  // "juan@test.com"
        
        // 4. PEDIR CONFIRMACIÓN
        if (confirm(`Are you sure you want to remove user ${userEmail}?`)) {
          // Usuario presionó OK
          
          try {
            // 5. ENVIAR PETICIÓN DELETE AL SERVIDOR
            await http.delete(`/users/${userId}`);
            
            // 6. RECARGAR LA PÁGINA PARA VER CAMBIOS
            await homeController();
            
            // El usuario fue eliminado ✓
          } catch (error) {
            console.error(error);
            alert("Error removing user. Please try again.");
          }
        } else {
          // Usuario presionó Cancelar - No hace nada
        }
      });
    });
};

// Esta función se llama desde homeController():
export const homeController = async () => {
  // ... código de reservas ...
  
  const user = getSession();
  if (user.role === "admin") {
    setupDeleteUserButtons();  // Solo para admins
  }
};
```

### Flujo cuando presionas "Remove":

```
┌───────────────────────────────────┐
│ Admin presiona "Remove"           │
└───────────────────────────────────┘
                ↓
        ┌───────────────────┐
        │ ¿Seguro que lo    │
        │ quieres eliminar? │
        │ [OK] [Cancelar]   │
        └───────────────────┘
                ↓
        ┌───────────────────┐
        │ Admin presiona OK │
        └───────────────────┘
                ↓
        ┌───────────────────┐
        │ DELETE /users/1   │
        │ Enviar al servidor│
        └───────────────────┘
                ↓
        ┌───────────────────┐
        │ Servidor:         │
        │ Elimina de db.json│
        │ Responde: OK      │
        └───────────────────┘
                ↓
        ┌───────────────────┐
        │ Recargar tabla    │
        │ (sin ese usuario) │
        └───────────────────┘
                ↓
        ┌───────────────────┐
        │ ¡Usuario eliminado│
        └───────────────────┘
```

---

## 🔐 Parte 3: Login (Inicio de Sesión)

### ¿Cómo validas que alguien es quién dice ser?

```javascript
// src/controllers/login.controller.js

export const loginController = () => {
  const loginForm = document.querySelector("#loginForm");
  
  if (loginForm) {
    loginForm.addEventListener("submit", async (e) => {
      e.preventDefault();
      
      // 1. OBTENER DATOS DEL FORMULARIO
      const formData = new FormData(loginForm);
      const { email, password } = Object.fromEntries(formData);
      
      try {
        // 2. OBTENER TODOS LOS USUARIOS
        const users = await http.get("/users");
        
        // 3. BUSCAR USUARIO CON ESE EMAIL
        const user = users.find((u) => u.email === email);
        
        // 4. VERIFICACIONES
        if (!user) {
          alert("Email not found");
          return;
        }
        
        if (user.password !== password) {
          alert("Incorrect password");
          return;
        }
        
        // 5. ¡TODO CORRECTO! GUARDAR EN LOCALSTORAGE
        localStorage.setItem("user", JSON.stringify(user));
        // Guarda: {id, name, email, role}
        
        // 6. IR A /home
        navigateTo("/home");
        
      } catch (error) {
        console.error(error);
        alert("Login error");
      }
    });
  }
};
```

### Verificación en cada página:

```javascript
// src/router/router.js

export const router = async () => {
  const app = document.querySelector("#app");
  let path = window.location.pathname;
  
  // 1. ¿Es una ruta protegida?
  const publicRoutes = ["/", "/login", "/register"];
  
  if (!publicRoutes.includes(path) && !isAuthenticated()) {
    // 2. NO está logeado y quiere ver ruta protegida
    path = "/";  // Llevalo a /login
  }
  
  // 3. Mostrar la vista
  const view = routes[path];
  const htmlContent = await view();
  app.innerHTML = htmlContent;
};
```

---

## 🗂️ Parte 4: Organización de Carpetas

```
src/
├── views/                    ← Lo que VES
│   ├── registerView.js       ← Formulario registro
│   ├── loginView.js          ← Formulario login
│   ├── homeView.js           ← Panel principal
│   └── notFound.js           ← Error 404
│
├── controllers/              ← La LÓGICA
│   ├── register.controller.js   ← Lógica del registro
│   ├── login.controller.js      ← Lógica del login
│   └── home.controller.js       ← Lógica del panel
│
├── components/               ← Partes REUTILIZABLES
│   ├── UserManagement.js     ← Tabla de usuarios
│   ├── ReservationCard.js    ← Tarjeta de reserva
│   ├── AdminDashboard.js     ← Estadísticas
│   └── Sidebar.js            ← Menú lateral
│
├── services/                 ← Funciones de BD
│   └── reservation.service.js ← CRUD de reservas
│
├── api/                      ← Comunicación
│   └── http.js               ← GET, POST, DELETE
│
├── router/                   ← Navegación
│   └── router.js             ← Control de rutas
│
├── utils.js                  ← Funciones útiles
├── main.js                   ← Punto de entrada
└── style.css                 ← Estilos
```

---

## 📊 Resumen de Archivos Clave

| Archivo | ¿Qué hace? | Ejemplo |
|---------|-----------|---------|
| `registerView.js` | Muestra formulario | El HTML que ves |
| `registerController.js` | Valida y guarda | Verifica email único |
| `UserManagement.js` | Muestra tabla de usuarios | La tabla que ves |
| `http.js` | Comunica con servidor | `await http.post()` |
| `db.json` | Base de datos | Archivo con usuarios |
| `router.js` | Controla URLs | `/register` → registerView |

---

## 🎯 Conclusión

### Flujo Completo de Registro:

```
1. Usuario va a /register
   ↓
2. Ve registerView (formulario)
   ↓
3. Llena datos y presiona "Create"
   ↓
4. registerController() se ejecuta
   ↓
5. Valida datos (campos, emails, passwords)
   ↓
6. Crea objeto newUser
   ↓
7. Envia via http.post() a /users
   ↓
8. Servidor (json-server) recibe
   ↓
9. Guarda en db.json
   ↓
10. Responde OK
    ↓
11. Se muestra "¡Éxito!"
    ↓
12. Redirige a /login
    ↓
13. Usuario puede logearse
```

---

## ✨ Ya Entiendes el Código!

✅ Cómo funciona el registro paso a paso
✅ Cómo se validan los datos
✅ Cómo se comunica con la base de datos
✅ Cómo se eliminan usuarios
✅ Cómo fluye la información

---

**¡Felicitaciones! Ahora sabes cómo funciona el código!** 🎉

