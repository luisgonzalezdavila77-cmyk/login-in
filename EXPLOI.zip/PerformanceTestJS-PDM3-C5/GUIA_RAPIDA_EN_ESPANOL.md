# ⚡ Guía Rápida - Explicación del Código en Español

## 📖 ¿Qué es esto?

Una explicación **FÁCIL Y SENCILLA** de cómo funciona el código de la aplicación de reservas.

---

## 🎯 Las 5 Carpetas Principales

### 1. **views/** - Lo que VES

Son las **páginas**:

```
registerView.js  ← Página para registrarse
loginView.js     ← Página para iniciar sesión
homeView.js      ← Página principal (después de loguear)
```

**Analogía**: Son como las páginas de un libro.

---

### 2. **controllers/** - La LÓGICA

Son las **funciones** que hacen cosas:

```
registerController.js  ← Valida que el registro esté correcto
loginController.js     ← Valida que el login esté correcto
homeController.js      ← Maneja las reservas
```

**Analogía**: Son como el cerebro que toma decisiones.

---

### 3. **components/** - Partes REUTILIZABLES

Son **bloques** que se usan en varias páginas:

```
UserManagement.js    ← Tabla de usuarios (solo para admin)
ReservationCard.js   ← Tarjeta de una reserva
AdminDashboard.js    ← Panel con estadísticas
Sidebar.js           ← Menú lateral
```

**Analogía**: Son como piezas de LEGO que se pueden reutilizar.

---

### 4. **services/** - CONEXIÓN A LA BASE DE DATOS

Son **funciones** para operaciones de base de datos:

```
reservation.service.js  ← Crear, leer, editar, eliminar reservas
```

**Analogía**: Es el empleado que busca información en los archivos.

---

### 5. **api/** - COMUNICACIÓN CON EL SERVIDOR

Es **como el cartero**:

```
http.js
├─ get()    ← Trae información
├─ post()   ← Envía información nueva
└─ delete() ← Elimina información
```

---

## 🔄 El Flujo del Registro

### Paso a Paso:

```
1️⃣  Usuario va a /register
    ↓
2️⃣  Ve formulario (registerView.js)
    └─ [Nombre] [Email] [Contraseña] [Confirmar]
    ↓
3️⃣  Llena datos y presiona "Crear"
    ↓
4️⃣  registerController.js valida:
    ✓ ¿Campos completos?
    ✓ ¿Passwords iguales?
    ✓ ✓ ¿Password >= 6 caracteres?
    ✓ ¿Email no existe?
    ↓
5️⃣  Si todo está bien:
    └─ Crea usuario nuevo
    └─ Guarda en db.json
    ↓
6️⃣  Muestra "¡Éxito!"
    ↓
7️⃣  Lo lleva a /login
    ↓
8️⃣  Ahora puede loguear
```

---

## 👥 Gestión de Usuarios (Admin)

### Lo que pasa:

```
1️⃣  Admin logueado va a /home
    ↓
2️⃣  Ve tabla "Registered Users"
    └─ ID │ Nombre │ Email │ Remove
    ↓
3️⃣  Admin presiona "Remove" de un usuario
    ↓
4️⃣  Pregunta: "¿Seguro?"
    ├─ [OK] ← Confirma
    └─ [Cancelar]
    ↓
5️⃣  Si presiona OK:
    └─ Usuario eliminado de db.json
    ↓
6️⃣  Tabla se actualiza automáticamente
```

---

## 🔐 El Login

### Cómo se valida:

```
Usuario entra: admin@test.com / A123456
    ↓
loginController valida:
    ✓ ¿Email existe en db.json?
    ✓ ¿Contraseña correcta?
    ↓
SI OK:
    └─ Guarda en localStorage
    └─ Va a /home
    ↓
SI ERROR:
    └─ Muestra error
    └─ No lo deja entrar
```

---

## 🗂️ Base de Datos (db.json)

### Tabla de Usuarios:

```json
{
  "id": "1",
  "name": "Juan",
  "email": "juan@test.com",
  "password": "A123456",
  "role": "user"  ← Puede ser "admin" o "user"
}
```

### Tabla de Reservas:

```json
{
  "id": "1",
  "userId": "1",           ← Quién reserva
  "workspace": "Oficina 1",  ← Qué espacio
  "date": "2026-06-10",    ← Qué fecha
  "startHour": "09:00",    ← Hora inicio
  "endHour": "12:00",      ← Hora fin
  "status": "pending",     ← pending/approved/rejected
  "spaceType": "oficina",  ← Tipo de espacio
  "price": "290.000"       ← Precio
}
```

---

## 📡 Las 3 Peticiones HTTP

### POST - Crear Usuario

```
Navegador                    Servidor
    │                           │
    ├── POST /users ──────────→ │
    │   {name, email, pass}     │
    │                           │ Guarda en db.json
    │                 ←── OK ── │
    │                           │
```

### GET - Traer Usuarios

```
Navegador                    Servidor
    │                           │
    ├── GET /users ──────────→ │
    │                           │
    │           ←── [usuarios] ─ │
    │                           │
```

### DELETE - Eliminar Usuario

```
Navegador                    Servidor
    │                           │
    ├── DELETE /users/1 ─────→ │
    │                           │ Elimina de db.json
    │                  ←── OK ─ │
    │                           │
```

---

## 🔑 Palabras Clave

| Término | Significa |
|---------|-----------|
| `async/await` | "Espera a que termine antes de continuar" |
| `fetch()` | Enviar petición al servidor |
| `localStorage` | Guardar datos en el navegador |
| `role` | Tipo de usuario (admin o user) |
| `status` | Estado (pending, approved, rejected) |
| `navigateTo()` | Cambiar de página SIN recargar |
| `router` | Controla qué página mostrar según la URL |

---

## ✅ Validaciones

### En el Registro:

- ❌ Campos vacíos
- ❌ Passwords no iguales  
- ❌ Password < 6 caracteres
- ❌ Email ya existe
- ✅ Todo correcto → Crea usuario

### En el Login:

- ❌ Email no existe
- ❌ Contraseña incorrecta
- ✅ Todo correcto → Entra al dashboard

---

## 🎬 El Ciclo de Vida

```
1. Usuario abre navegador
   ↓
2. Va a URL (/register, /login, /home)
   ↓
3. router() lee la URL
   ↓
4. Se carga la vista (view)
   ↓
5. Se ejecuta el controlador (controller)
   ↓
6. Se agregan eventos a botones
   ↓
7. Usuario puede interactuar
   ↓
8. Usuario presiona botón
   ↓
9. Controller ejecuta lógica
   ↓
10. Si necesita, hace petición al servidor
    ↓
11. Se actualiza la página
    ↓
12. Usuario ve cambios
```

---

## 🎨 La Interfaz

### Para Usuario Normal:

```
┌─────────────────────────────────┐
│ Menú lateral                    │
│                                 │
│ [Home] [Logout]                 │
│                                 │
│ Bienvenido Juan                 │
│ Rol: Usuario                    │
│                                 │
│ MIS RESERVAS                    │
│ [+ Nueva Reserva]               │
│                                 │
│ [Tarjeta Reserva 1]             │
│ [Tarjeta Reserva 2]             │
└─────────────────────────────────┘
```

### Para Admin:

```
┌─────────────────────────────────┐
│ Menú lateral                    │
│                                 │
│ [Home] [Logout]                 │
│                                 │
│ Bienvenido Admin                │
│ Rol: Administrador              │
│                                 │
│ PANEL ADMIN                     │
│ • Salas: 5                      │
│ • Dinero: $1.450.000           │
│ • Pendientes: 2                 │
│                                 │
│ USUARIOS REGISTRADOS            │
│ │ ID │ Name │ Email │ Remove   │
│ │ 1  │ Juan │ j@... │ [X]      │
│                                 │
│ TODAS LAS RESERVAS              │
│ [+ Nueva Reserva]               │
│                                 │
│ [Tarjeta Reserva 1]             │
│ [Tarjeta Reserva 2]             │
└─────────────────────────────────┘
```

---

## 🚀 Cómo Funciona Todo Junto

```
┌─────────────────────────────────────────────────────┐
│              LO QUE VES (Views)                     │
│  registerView.js, loginView.js, homeView.js        │
└─────────────────────────────────────────────────────┘
                     ↑ ↓
┌─────────────────────────────────────────────────────┐
│         LA LÓGICA (Controllers)                     │
│  registerController.js, loginController.js         │
└─────────────────────────────────────────────────────┘
                     ↑ ↓
┌─────────────────────────────────────────────────────┐
│       PARTES REUTILIZABLES (Components)            │
│  UserManagement.js, ReservationCard.js             │
└─────────────────────────────────────────────────────┘
                     ↑ ↓
┌─────────────────────────────────────────────────────┐
│   COMUNICACIÓN CON SERVIDOR (http.js)              │
│  GET, POST, DELETE                                  │
└─────────────────────────────────────────────────────┘
                     ↑ ↓
┌─────────────────────────────────────────────────────┐
│         LA BASE DE DATOS (db.json)                 │
│  Usuarios, Reservas                                │
└─────────────────────────────────────────────────────┘
```

---

## 💡 Resumen Fácil

| Acción | Qué Pasa |
|--------|----------|
| Usuario va a /register | Se muestra formulario |
| Llena datos | registerController valida |
| Presiona crear | Se crea usuario en db.json |
| Usuario va a /login | Se muestra formulario |
| Entra credenciales | loginController valida |
| Presiona entrar | Se guarda sesión, va a /home |
| Admin va a /home | Ve tabla de usuarios |
| Admin presiona remove | Se elimina de db.json |

---

## 🔐 Seguridad (Importante)

### Ahora:
- ✅ Validaciones funcionales
- ✅ Contraseñas guardadas (texto plano)
- ✅ Email único

### Para Producción:
- ❌ Encriptar contraseñas (bcrypt)
- ❌ HTTPS
- ❌ Validar en servidor también
- ❌ Rate limiting

---

## 📚 Archivos Clave

| Archivo | ¿Qué hace? |
|---------|-----------|
| `registerView.js` | Muestra el formulario |
| `registerController.js` | Valida y crea usuario |
| `homeView.js` | Muestra dashboard |
| `UserManagement.js` | Muestra tabla de usuarios |
| `homeController.js` | Maneja clics de botones |
| `http.js` | Envía/recibe del servidor |
| `db.json` | Base de datos |
| `router.js` | Controla qué página mostrar |

---

## 🎯 Preguntas Frecuentes

**¿Dónde se guardan los usuarios?**
→ En db.json, tabla "users"

**¿Qué es localStorage?**
→ Memoria del navegador para guardar sesión

**¿Por qué `async/await`?**
→ Porque el servidor es lento, espera a terminar

**¿Qué es `role`?**
→ El tipo de usuario: "admin" o "user"

**¿Por qué se ejecuta `homeController()` dos veces?**
→ Una al cargar la página, otra para actualizar

**¿Cómo sabe si estás logeado?**
→ Verifica si hay algo en localStorage

**¿Por qué algunos botones no funcionan?**
→ Probablemente falta `setupDeleteUserButtons()`

---

## 🐛 Solución de Problemas

| Problema | Solución |
|----------|----------|
| No funciona nada | ¿Están los 2 servidores corriendo? |
| No puede registrarse | ¿El email ya existe? |
| No puede loguearse | ¿Email y contraseña correctos? |
| No ve usuarios | ¿Eres admin? (role === "admin") |
| Botón no funciona | Abre consola (F12) y busca errores |
| Se desloguea al refrescar | Probablemente localStorage limpio |

---

## ✨ Lo Más Importante

```
FLUJO BÁSICO:

1. Usuario se registra
   └─ Datos guardados en db.json
   
2. Usuario inicia sesión
   └─ Sesión guardada en localStorage
   
3. Usuario hace cosas (reservas, etc)
   └─ Se comunica con servidor
   
4. Admin gestiona usuarios
   └─ Puede eliminar usuarios de db.json
   
5. TODO SIN RECARGAR LA PÁGINA
   └─ Usa SPA (Single Page Application)
```

---

## 🎓 Ahora Entiendes

✅ Cómo funciona el registro
✅ Cómo se valida información
✅ Cómo se comunica con el servidor
✅ Cómo se eliminan usuarios
✅ Cómo fluye la información

---

## 📖 Para Más Detalles

- **EXPLICACION_CODIGO_SIMPLE.md** - Más detallado
- **CODIGO_EXPLICADO_CON_EJEMPLOS.md** - Con ejemplos
- **DIAGRAMAS_Y_FLUJOS.md** - Visuales y diagramas
- **README.md** - Documentación técnica

---

**¡Ahora entiendes el código completo!** 🎉

Si tienes dudas sobre algo específico, pregunta y te lo explico aún más simple.

