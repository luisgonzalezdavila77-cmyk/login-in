# LGC Office Reservation System

## General Description

This is a Single Page Application (SPA) for managing space reservations at a company called LGC. It allows employees to reserve meeting rooms, private offices, and other spaces, while administrators can manage all system reservations.

## System Name

LGC Office Reservation System - Comprehensive space management system

## Technologies Used

- Vanilla JavaScript (ES6+)
- Vite as build tool
- TailwindCSS for styling
- json-server for simulated API
- LocalStorage for session persistence

## System Requirements

- Node.js version 14 or higher
- npm or yarn as package manager
- Modern web browser

## Installation

1. Download or clone the project
2. Open terminal in project folder
3. Run: npm install
4. This will install all necessary dependencies

## Execution

Command to start both servers simultaneously:

```
npm run dev
```

This starts:
- Vite dev server at http://localhost:5173
- json-server at http://localhost:3001

If you have issues with npm run dev (especially on Snap), run in two separate terminals:

Terminal 1:
```
npx vite
```

Terminal 2:
```
npx json-server --watch db.json --port 3001
```

## Application Access

Open in your browser: http://localhost:5173

## Test Credentials

Administrator:
- Email: admin@test.com
- Password: A123456

Regular User:
- Email: user@test.com
- Password: A123456

User 2:
- Email: user2@test.com
- Password: A123456

## Project Structure

src/
  api/              - HTTP module for API communication
  components/       - Reusable components (cards, sidebar)
  controllers/      - Application logic
  services/         - API call services
  views/            - Main application views
  router/           - Routing system (History API)
  utils.js          - Helper functions
  main.js           - Entry point
  style.css         - Global styles

db.json             - Simulated database
package.json        - Project dependencies
vite.config.js      - Vite configuration

## Main Features

### For Regular Users

- Create new space reservations
- View all their own reservations
- Edit pending reservations
- Delete pending reservations
- Cancel approved reservations

### For Administrators

- View all system reservations
- Create reservations
- Edit any reservation
- Delete any reservation
- Approve pending reservations
- Reject pending reservations

## Reservation Data

Each reservation contains:

- ID: Unique identifier (auto-generated)
- Requesting User: ID of user creating reservation
- Reserved Space: Space name
- Date: Reservation date
- Start Time: Reservation start time
- End Time: Reservation end time
- Reason: Reservation reason
- Status: pending, approved, rejected or cancelled
- Space Type: Office, Coworking, Meeting Room, Auditorium, Other
- Price: Price per day for the space type

## Reservation Statuses

- pending: Reservation waiting for admin approval
- approved: Reservation has been approved
- rejected: Reservation has been rejected
- cancelled: Reservation has been cancelled

## Business Rules

- Cannot create duplicate reservations for same space and time
- User can only modify their own reservations if in pending status
- Approved reservations can only be cancelled
- Administrator can modify any reservation in any status
- User session persists even when refreshing the page

## Navigation Without Reloading

The application uses History API to change URLs without reloading the page. This provides a smoother and faster experience.

## Session Persistence

User session is saved in browser localStorage. This allows:

- User to remain logged in when refreshing the page
- No need to log in again
- Session data cleaned up when logging out

## Error Handling

The application handles errors in:

- Login credentials validation
- API communication
- Reservation CRUD operations
- User permissions

Clear messages are shown to users when errors occur.

## Database

The db.json file contains:

- Users table with roles (admin/user)
- Reservations table with all data
- Test data for immediate use

## Development

To make changes in code:

1. Edit files in src/
2. Vite will automatically reload application in browser
3. Changes are visible immediately in real time

## Building for Production

```
npm run build
```

This creates a dist/ folder with optimized files.

## Common Problems

If application doesn't load:

1. Verify both servers are running
2. Open console (F12) in browser
3. Look for error messages
4. Verify URLs are correct (localhost:5173 and localhost:3001)

If data doesn't save:

1. Verify json-server is running on port 3001
2. Open DevTools (F12) and go to Network tab
3. Verify HTTP requests are being sent

## Additional Documentation

- DASHBOARD_ADMIN.md: Complete admin dashboard documentation
- GUIA_RAPIDA_DASHBOARD.md: Quick visual guide for dashboard
- TECHNICAL_SPEC.md: Complete technical specifications

## Space Types and Pricing

| Space Type | Price |
|-----------|-------|
| Private Office | $290.000/day |
| Coworking | $350.000/day |
| Meeting Room | $420.000/day |
| Auditorium | $550.000/day |
| Other | Consult price |

## Admin Dashboard

Exclusive dashboard for administrators showing:

- **Reserved Spaces**: Total reservations in the system
- **Revenue**: Total income from approved reservations
- **Pending Requests**: Reservations waiting for approval
- **Available Spaces**: Spaces ready for reservation

Plus additional sections:

- **Availability by Type**: Occupancy percentage for each space type
- **Revenue Summary**: Income breakdown by space type

## Features Implemented

✅ Authentication with roles (admin/user)
✅ Complete CRUD for reservations
✅ Dynamic pricing system (5 space types)
✅ Reservation approval/rejection (admin)
✅ Role-based data filtering
✅ Navigation without page reloads (History API)
✅ Session persistence (localStorage)
✅ Responsive interface (TailwindCSS)
✅ Admin Dashboard
✅ Space selector with numbering
✅ All 20 mandatory requirements implemented

## Author

Developed as a space management project for company.

## License

Educational project - free to use.
