/**
 * ROUTER ALTERNATIVO: Hash-based Routing
 * 
 * Este archivo muestra una ALTERNATIVA usando hash en lugar de History API
 * No está en uso, es solo para referencia educativa
 * 
 * Comparación:
 * ├─ History API (router.js): http://localhost:5173/home
 * └─ Hash-based: http://localhost:5173/#/home
 * 
 * NOTA: El proyecto utiliza History API (router.js), NO este archivo
 */

import loginView from "@/views/loginView";
import homeView from "@/views/homeView";
import notFoundView from "@/views/notFound";
import { isAuthenticated } from "@/utils";

const publicRoutes = ["/", "/login"];

const routes = {
  "/": loginView,
  "/login": loginView,
  "/home": homeView,
  "/404": notFoundView,
};

/**
 * ALTERNATIVA: Navegación con Hash
 * 
 * En lugar de:
 *   navigateTo("/home") → URL: /home
 * 
 * Usaría:
 *   navigateToHash("/home") → URL: /#/home
 */
export const navigateToHash = (path) => {
  // Cambiar solo el hash (fragmento de URL)
  // El # solo existe en el cliente, no se envía al servidor
  window.location.hash = path;
  // El evento hashchange se dispara automáticamente
};

/**
 * ALTERNATIVA: Router con Hash
 * 
 * En lugar de leer pathname:
 *   window.location.pathname
 * 
 * Lee el hash:
 *   window.location.hash
 */
export const routerHash = () => {
  const app = document.querySelector("#app");

  // ✓ Leer hash y remover el "#" inicial
  // Ejemplo: "#/home" → "/home"
  let path = window.location.hash.slice(1) || "/";

  // Validar acceso a rutas protegidas (igual que History API)
  if (!publicRoutes.includes(path) && !isAuthenticated()) {
    path = "/";
  }

  const view = routes[path];

  if (!view) {
    path = "/404";
  }

  app.innerHTML = routes[path]();
};

/**
 * ALTERNATIVA: Listener para cambios de hash
 * 
 * En lugar de:
 *   window.addEventListener("popstate", router)
 * 
 * Usaría:
 *   window.addEventListener("hashchange", routerHash)
 */
window.addEventListener("hashchange", routerHash);

/**
 * COMPARACIÓN DETALLADA
 * 
 * ┌─────────────────────────────────────────────────────────────┐
 * │                 HISTORY API VS HASH-BASED                   │
 * ├─────────────────────────────────────────────────────────────┤
 * │ Aspecto         │ History API        │ Hash-based          │
 * ├─────────────────┼────────────────────┼─────────────────────┤
 * │ URL             │ /home              │ /#/home             │
 * │ Método          │ pushState/popstate │ hash/hashchange     │
 * │ Limpeza URL     │ ✓ Excelente        │ ✗ Menos limpia      │
 * │ SEO             │ ✓ Mejor            │ ✗ Problemático      │
 * │ Server Config   │ Requiere rewrite   │ Directo (sin config)│
 * │ Compatibilidad  │ IE10+              │ IE6+                │
 * │ Offline         │ ✓ Funciona bien    │ ✓ Funciona bien     │
 * │ Performance     │ ✓ Muy similar      │ ✓ Muy similar       │
 * │ Testing         │ ✓ Más fácil        │ ✗ Hash complica     │
 * └─────────────────┴────────────────────┴─────────────────────┘
 * 
 * RECOMENDACIÓN:
 * - Usar HISTORY API (router.js) para aplicaciones modernas
 * - Usar HASH-BASED solo si necesitas máxima compatibilidad
 */

/**
 * ¿CUÁNDO USAR CADA UNA?
 * 
 * HISTORY API (RECOMENDADA):
 * ✓ Navegadores modernos (Chrome, Firefox, Safari, Edge)
 * ✓ Aplicaciones web profesionales
 * ✓ Cuando controlamos el servidor
 * ✓ Para mejores URLs y SEO
 * 
 * HASH-BASED:
 * ✓ Máxima compatibilidad con navegadores viejos
 * ✓ Hospedaje sin control de servidor
 * ✓ Archivos locales (file://)
 * ✓ Cuando no puedes configurar rewrite rules
 */
