import { getSession, isAdmin } from "@/utils";

export default function ReservationCard(
  reservation,
) {
  const {
    id,
    workspace,
    date,
    startHour,
    endHour,
    reason,
    status,
    userId,
    spaceType,
    price,
  } = reservation;
  const user = getSession();
  const isOwner = userId === user?.id;
  const userIsAdmin = isAdmin();

  const statusColor = {
    pending: "bg-yellow-100 text-yellow-800",
    approved: "bg-green-100 text-green-800",
    rejected: "bg-red-100 text-red-800",
  };

  const spaceTypeNames = {
    oficina: "Oficina Privada",
    coworking: "Coworking",
    "sala-juntas": "Sala de Juntas",
    auditorio: "Auditorio",
    otro: "Otro",
  };

  const prices = {
    oficina: "290.000",
    coworking: "350.000",
    "sala-juntas": "420.000",
    auditorio: "550.000",
    otro: "Consultar",
  };

  const canEdit =
    userIsAdmin || (isOwner && status === "pending");
  const canDelete =
    userIsAdmin ||
    (isOwner && status === "pending");
  const canApprove =
    userIsAdmin && status === "pending";
  const canReject =
    userIsAdmin && status === "pending";

  const displayPrice = price || prices[spaceType] || "Sin precio";

  return `
    <article
      class="border rounded-lg p-4 bg-white shadow hover:shadow-lg transition"
    >
      <div class="flex justify-between items-start mb-3">
        <h3 class="font-bold text-lg">
          ${workspace}
        </h3>
        <span
          class="px-2 py-1 text-xs font-bold rounded ${statusColor[status] || "bg-gray-100 text-gray-800"}"
        >
          ${status.charAt(0).toUpperCase() + status.slice(1)}
        </span>
      </div>

      <div class="space-y-2 text-sm mb-4">
        <p>
          <strong>Tipo:</strong> ${spaceTypeNames[spaceType] || spaceType || "No especificado"}
        </p>

        <p>
          <strong>Precio:</strong> $${displayPrice}/día
        </p>

        <p>
          <strong>Fecha:</strong> ${date}
        </p>

        <p>
          <strong>Horario:</strong> ${startHour} - ${endHour}
        </p>

        <p>
          <strong>Motivo:</strong> ${reason}
        </p>
      </div>

      <div class="flex gap-2 flex-wrap">
        ${
          canEdit
            ? `<button
            data-edit-btn="${id}"
            class="text-xs bg-blue-600 text-white px-3 py-1 rounded hover:bg-blue-700 transition"
          >
            Editar
          </button>`
            : ""
        }

        ${
          canDelete
            ? `<button
            data-delete-btn="${id}"
            class="text-xs bg-red-600 text-white px-3 py-1 rounded hover:bg-red-700 transition"
          >
            Eliminar
          </button>`
            : ""
        }

        ${
          canApprove
            ? `<button
            data-approve-btn="${id}"
            class="text-xs bg-green-600 text-white px-3 py-1 rounded hover:bg-green-700 transition"
          >
            Aprobar
          </button>`
            : ""
        }

        ${
          canReject
            ? `<button
            data-reject-btn="${id}"
            class="text-xs bg-orange-600 text-white px-3 py-1 rounded hover:bg-orange-700 transition"
          >
            Rechazar
          </button>`
            : ""
        }
      </div>
    </article>
  `;
}
