import { http } from "@/api/http";

export default async function UserManagement() {
  try {
    const users = await http.get("/users");

    // Filter out test admin
    const managedUsers = users.filter(
      (u) => u.email !== "admin@test.com"
    );

    return `
      <section class="bg-white p-6 rounded-lg shadow mb-6">
        <h2 class="font-bold text-xl mb-4">
          Registered Users
        </h2>

        <div class="overflow-x-auto">
          <table class="w-full">
            <thead>
              <tr class="border-b-2 border-slate-300">
                <th class="text-left p-3 text-sm font-semibold text-slate-700">
                  ID
                </th>
                <th class="text-left p-3 text-sm font-semibold text-slate-700">
                  Name
                </th>
                <th class="text-left p-3 text-sm font-semibold text-slate-700">
                  Email
                </th>
                <th class="text-left p-3 text-sm font-semibold text-slate-700">
                  Role
                </th>
                <th class="text-left p-3 text-sm font-semibold text-slate-700">
                  Status
                </th>
                <th class="text-left p-3 text-sm font-semibold text-slate-700">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody>
              ${
                managedUsers.length > 0
                  ? managedUsers
                      .map(
                        (user) => `
                  <tr class="border-b border-slate-200 hover:bg-slate-50 transition">
                    <td class="p-3 text-sm text-slate-600">
                      ${user.id}
                    </td>
                    <td class="p-3 text-sm font-medium text-slate-900">
                      ${user.name}
                    </td>
                    <td class="p-3 text-sm text-slate-600">
                      ${user.email}
                    </td>
                    <td class="p-3 text-sm">
                      <span class="px-3 py-1 rounded-full text-xs font-semibold ${
                        user.role === "admin"
                          ? "bg-purple-100 text-purple-800"
                          : "bg-blue-100 text-blue-800"
                      }">
                        ${
                          user.role === "admin"
                            ? "Administrator"
                            : "User"
                        }
                      </span>
                    </td>
                    <td class="p-3 text-sm">
                      <span class="px-3 py-1 rounded-full text-xs font-semibold bg-green-100 text-green-800">
                        Active
                      </span>
                    </td>
                    <td class="p-3 text-sm space-x-2">
                      <button
                        class="data-remove-user bg-red-600 hover:bg-red-700 text-white px-3 py-1 rounded text-xs transition"
                        data-user-id="${user.id}"
                        data-user-email="${user.email}"
                      >
                        Remove
                      </button>
                    </td>
                  </tr>
                `
                      )
                      .join("")
                  : `
                  <tr>
                    <td colspan="6" class="p-3 text-center text-slate-500">
                      No users registered yet
                    </td>
                  </tr>
                `
              }
            </tbody>
          </table>
        </div>

        <div class="mt-4 p-4 bg-blue-50 border border-blue-200 rounded-lg">
          <p class="text-sm text-blue-900">
            <strong>Total Users:</strong> ${managedUsers.length}
          </p>
          <p class="text-sm text-blue-900 mt-1">
            <strong>Administrators:</strong> 
            ${users.filter((u) => u.role === "admin").length}
          </p>
        </div>
      </section>
    `;
  } catch (error) {
    console.error(error);
    return `
      <div class="bg-red-100 border border-red-300 text-red-800 p-4 rounded mb-6">
        Error loading user management: ${error.message}
      </div>
    `;
  }
}
