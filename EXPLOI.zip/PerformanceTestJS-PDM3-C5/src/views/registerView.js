import { navigateTo } from "@/router/router";
import { http } from "@/api/http";

export default function registerView() {
  return `
    <div class="flex items-center justify-center min-h-screen bg-gradient-to-br from-slate-900 to-slate-700 p-4">
      <div class="bg-white rounded-lg shadow-2xl p-8 w-full max-w-md">
        
        <h1 class="text-3xl font-bold text-center mb-2 text-slate-800">
          LGC Reserva de Oficinas
        </h1>
        
        <p class="text-center text-slate-600 mb-6">
          Create a new account
        </p>

        <form id="registerForm" class="space-y-4">
          
          <div>
            <label class="block text-sm font-medium text-slate-700 mb-1">
              Full Name
            </label>
            <input
              type="text"
              id="name"
              name="name"
              placeholder="John Doe"
              class="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500"
              required
            >
            <span class="error text-red-500 text-sm hidden"></span>
          </div>

          <div>
            <label class="block text-sm font-medium text-slate-700 mb-1">
              Email
            </label>
            <input
              type="email"
              id="email"
              name="email"
              placeholder="your@email.com"
              class="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500"
              required
            >
            <span class="error text-red-500 text-sm hidden"></span>
          </div>

          <div>
            <label class="block text-sm font-medium text-slate-700 mb-1">
              Password
            </label>
            <input
              type="password"
              id="password"
              name="password"
              placeholder="Minimum 6 characters"
              class="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500"
              required
              minlength="6"
            >
            <span class="error text-red-500 text-sm hidden"></span>
          </div>

          <div>
            <label class="block text-sm font-medium text-slate-700 mb-1">
              Confirm Password
            </label>
            <input
              type="password"
              id="confirmPassword"
              name="confirmPassword"
              placeholder="Confirm password"
              class="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500"
              required
              minlength="6"
            >
            <span class="error text-red-500 text-sm hidden"></span>
          </div>

          <button
            type="submit"
            class="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-medium py-2 rounded-lg transition duration-200"
          >
            Create Account
          </button>

        </form>

        <p class="text-center text-slate-600 mt-6">
          Already have an account?
          <a
            href="#"
            onclick="event.preventDefault(); navigateTo('/login')"
            class="text-emerald-600 hover:text-emerald-700 font-medium"
          >
            Sign in
          </a>
        </p>

      </div>
    </div>
  `;
}

// Make navigateTo available in onclick
window.navigateTo = navigateTo;
