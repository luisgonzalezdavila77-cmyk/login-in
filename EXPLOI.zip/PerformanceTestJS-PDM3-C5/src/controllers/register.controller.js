import { http } from "@/api/http";
import { navigateTo } from "@/router/router";

export const registerController = () => {
  const registerForm = document.querySelector("#registerForm");

  if (registerForm) {
    registerForm.addEventListener("submit", async (e) => {
      e.preventDefault();

      const formData = new FormData(registerForm);
      const data = Object.fromEntries(formData);

      // Validations
      if (!data.name || !data.email || !data.password || !data.confirmPassword) {
        alert("All fields are required");
        return;
      }

      if (data.password !== data.confirmPassword) {
        alert("Passwords do not match");
        return;
      }

      if (data.password.length < 6) {
        alert("Password must be at least 6 characters");
        return;
      }

      try {
        // Check if email already exists
        const users = await http.get("/users");
        const emailExists = users.some(
          (user) => user.email === data.email
        );

        if (emailExists) {
          alert("Email already registered. Try with a different email or sign in.");
          return;
        }

        // Create new user (default role: user)
        const newUser = {
          id: Date.now().toString(),
          name: data.name,
          email: data.email,
          password: data.password, // In production, this should be hashed
          role: "user", // Default role
        };

        await http.post("/users", newUser);

        alert("Account created successfully! You can now sign in.");
        navigateTo("/login");
      } catch (error) {
        console.error(error);
        alert("Error creating account. Please try again.");
      }
    });
  }
};
