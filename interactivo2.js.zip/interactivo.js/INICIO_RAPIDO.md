# 🚀 Inicio Rápido - Guía de 5 Minutos

Comienza a usar la aplicación en 5 minutos.

---

## ⚡ Opción 1: Sin Servidor (Solo Local Storage) - 30 segundos

### Paso 1: Abre el archivo
1. En tu explorador de archivos, busca `index.html`
2. Haz doble clic para abrirlo en el navegador
3. ¡Listo! La aplicación está funcionando

### Paso 2: Prueba
1. Escribe un nombre: "Mi Primer Producto"
2. Escribe un precio: "99.99"
3. Haz clic en "✅ Agregar Producto"
4. ¡Tu producto aparece en la lista!

---

## 🔌 Opción 2: Con Servidor API - 5 minutos

### Paso 1: Instala JSON Server (1 minuto)
```bash
npm install -g json-server
```

### Paso 2: Inicia el servidor (1 minuto)
```bash
json-server --watch db.json
```

Deberías ver:
```
✓ Your API is running at http://localhost:3000
```

### Paso 3: Abre la aplicación (1 minuto)
1. Abre `index.html` en el navegador
2. Agrega algunos productos
3. Haz clic en "🔄 Sincronizar con API"

### Paso 4: Verifica la sincronización (2 minutos)
1. Abre `db.json` en un editor
2. Verifica que tus productos están allí
3. ¡Sincronización completada! ✅

---

## 📋 Tareas Rápidas

### Agregar Producto
```
1. Completa el formulario
2. Haz clic en "✅ Agregar Producto"
3. Listo, aparece en la lista
```

### Editar Producto
```
1. Haz clic en "✏️ Editar"
2. Actualiza los datos en los prompts
3. Listo, cambios guardados
```

### Eliminar Producto
```
1. Haz clic en "🗑️ Eliminar"
2. Confirma la eliminación
3. Listo, se elimina
```

### Sincronizar con API
```
1. Asegúrate que JSON Server esté corriendo
2. Haz clic en "🔄 Sincronizar con API"
3. Verifica la consola (F12)
4. Listo, datos sincronizados
```

---

## 🔍 Verificar que Funciona

### En el navegador
- ✅ Los productos aparecen en la lista
- ✅ Los mensajes de éxito son verdes
- ✅ Los errores son rojos

### En la consola (F12)
```
✅ Productos cargados desde Local Storage
✅ Producto agregado: {...}
✅ Producto "XYZ" agregado exitosamente
```

### En el Local Storage (F12 → Application)
```
Key: productos_app
Value: [{"id":123, "nombre":"...", ...}]
```

---

## 🛠️ Solución Rápida de Problemas

### "No veo mis productos al recargar"
```
Solución: Verifica la consola (F12)
Si ves error de Local Storage,
recarga la página (Ctrl+F5)
```

### "Sincronizar no funciona"
```
Solución: Verifica que JSON Server esté corriendo
Terminal: json-server --watch db.json
```

### "El formulario no responde"
```
Solución: Recarga la página (Ctrl+F5)
Abre la consola y busca errores (F12)
```

---

## 📊 Estructura de Carpeta

```
Tu Carpeta del Proyecto/
├── index.html                    👈 Abre esto
├── app.js                        (Se carga automáticamente)
├── db.json                       (Base de datos)
└── README.md                     (Documentación completa)
```

---

## 🎯 Próximos Pasos

Una vez que tengas todo funcionando:

1. **Lee la documentación:**
   - `README.md` - Documentación completa
   - `ESTRUCTURA_CODIGO.md` - Cómo funciona el código

2. **Ejecuta todas las pruebas:**
   - `INSTRUCCIONES_PRUEBA.md` - Pruebas por TASK
   - `VERIFICACION_CONSOLA.md` - Comandos de consola

3. **Personaliza la aplicación:**
   - Cambia colores en `index.html` (CSS)
   - Agrega más campos en `app.js`
   - Cambia la URL de la API en `app.js`

---

## 📱 Accesos Rápidos

| Acción | Comando |
|--------|---------|
| Abrir consola | F12 |
| Abrir DevTools | Ctrl + Shift + I |
| Recargar página | F5 o Ctrl + R |
| Fuerza recarga | Ctrl + F5 |
| Iniciar JSON Server | `json-server --watch db.json` |

---

## ✨ Lo que hace tu aplicación

✅ Agrega y elimina productos
✅ Edita información
✅ Guarda automáticamente en Local Storage
✅ Persiste datos entre sesiones
✅ Sincroniza con un servidor API
✅ Muestra estadísticas en vivo
✅ Interfaz moderna y responsiva

---

## 🎓 Qué aprendes

Durante el desarrollo, aprendiste:
- Manipulación del DOM
- Local Storage
- Fetch API
- Validación de datos
- Manejo de errores
- JavaScript moderno (ES6+)

---

## 🎉 ¡Felicidades!

¡Ya tienes una aplicación CRUD completamente funcional!

Si necesitas ayuda, consulta:
- `README.md` - Documentación
- `ESTRUCTURA_CODIGO.md` - Explicación del código
- `INSTRUCCIONES_PRUEBA.md` - Cómo probar cada parte

---

**¡Empienza ya! Abre `index.html` en tu navegador 🚀**

---

*Última actualización: 03/06/2026*
