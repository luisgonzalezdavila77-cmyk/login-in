// ========================================
// SISTEMA INTERACTIVO DE BIENVENIDA
// ========================================
// Este script solicita datos del usuario, valida la edad
// y muestra mensajes personalizados según su mayoría/minoría de edad.

// ========================================
// TASK 2: ENTRADA DE DATOS DEL USUARIO
// ========================================
// Solicita el nombre del usuario mediante prompt()
const nombre = prompt("¿Cuál es tu nombre?");

// Solicita la edad del usuario mediante prompt()
// El valor ingresado será una cadena de texto inicialmente
const edadIngresada = prompt("¿Cuál es tu edad?");

// ========================================
// TASK 3: VALIDACIÓN DE LA EDAD
// ========================================
// Convierte la cadena ingresada a número
const edad = Number(edadIngresada);

// Comprueba si el valor ingresado es realmente un número válido
// isNaN() retorna true si NO es un número
// También validamos que la edad sea positiva
if (isNaN(edad) || edad <= 0) {
  // Si no es un número válido, muestra un mensaje de error
  console.error("Error: Por favor, ingresa una edad válida en números.");
} else {
  // ========================================
  // TASK 4: CONDICIONALES Y MENSAJES DINÁMICOS
  // ========================================
  
  // Verifica si el usuario es menor de edad (menor a 18)
  if (edad < 18) {
    const mensajeMenor = `Hola ${nombre}, eres menor de edad. ¡Sigue aprendiendo y disfrutando del código!`;
    console.log(mensajeMenor);
    alert(mensajeMenor);
  } 
  // Verifica si el usuario es mayor o igual a 18 años
  else {
    const mensajeMayor = `Hola ${nombre}, eres mayor de edad. ¡Prepárate para grandes oportunidades en el mundo de la programación!`;
    console.log(mensajeMayor);
    alert(mensajeMayor);
  }
  
  // Información adicional en consola para seguimiento
  console.log(`Datos registrados: Nombre = ${nombre}, Edad = ${edad}`);
}
