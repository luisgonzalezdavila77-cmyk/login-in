# 📦 Gestor de Productos - Aplicación CRUD Completa

Una aplicación web moderna para gestionar productos con persistencia en **Local Storage** e integración con **Fetch API**.

## ✨ Características Principales

- ✅ **CRUD Completo**: Crear, Leer, Actualizar y Eliminar productos
- ✅ **Local Storage**: Persistencia automática de datos entre sesiones
- ✅ **Fetch API**: Sincronización con servidor (JSON Server)
- ✅ **Validaciones**: Control de entrada de datos
- ✅ **Interfaz Moderna**: Diseño responsivo y atractivo
- ✅ **Estadísticas en Vivo**: Total de productos, valor total, promedio de precio
- ✅ **Manejo de Errores**: Try-catch y mensajes informativos
- ✅ **Código Comentado**: Documentación detallada en cada sección

---

## 🚀 Instalación y Configuración

### Opción 1: Uso sin servidor (Solo Local Storage)

1. Simplemente abre `index.html` en tu navegador
2. Los datos se guardarán en Local Storage automáticamente
3. Los datos persisten entre sesiones

### Opción 2: Uso con JSON Server (Sincronización con API)

#### Requisitos
- Node.js instalado

#### Pasos

1. **Instala JSON Server globalmente**
   ```bash
   npm install -g json-server
   ```

2. **Crea el archivo de base de datos** (ya incluido como `db.json`)
   ```json
   {
     "productos": []
   }
   ```

3. **Inicia JSON Server**
   ```bash
   json-server --watch db.json
   ```
   El servidor correrá en: `http://localhost:3000`

4. **Abre `index.html` en tu navegador**

5. **Usa el botón "Sincronizar con API"** para sincronizar datos con el servidor

---

## 📋 Estructura del Proyecto

```
├── index.html          # Estructura HTML y estilos CSS
├── app.js              # Lógica de JavaScript (DOM, Local Storage, Fetch API)
├── db.json             # Base de datos para JSON Server
└── README.md           # Este archivo
```

---

## 📖 Guía de Uso

### 1. Agregar un Producto

1. Completa los campos del formulario:
   - **Nombre**: Obligatorio (Ej: Laptop, Mouse, etc.)
   - **Precio**: Obligatorio (debe ser un número positivo)
   - **Descripción**: Opcional

2. Haz clic en **"✅ Agregar Producto"**

3. El producto aparecerá en la lista y se guardará automáticamente en Local Storage

### 2. Ver Productos

- Los productos se muestran en la lista con:
  - Nombre
  - Precio
  - Descripción
  - Fecha de creación

### 3. Editar un Producto

1. Haz clic en el botón **"✏️ Editar"** del producto
2. Actualiza los datos en los prompts
3. Los cambios se guardan automáticamente

### 4. Eliminar un Producto

1. Haz clic en el botón **"🗑️ Eliminar"**
2. Confirma la eliminación
3. El producto se elimina del DOM y Local Storage

### 5. Sincronizar con API

1. Haz clic en **"🔄 Sincronizar con API"**
2. Los productos locales se enviarán al servidor
3. Verifica la consola para ver los detalles

### 6. Limpiar Todo

1. Haz clic en **"🗑️ Limpiar Todo"**
2. Confirma la acción
3. Se eliminarán todos los productos

---

## 🎯 Funcionalidades por TASK

### TASK 2: Captura e Interacción con el Usuario
- ✅ Formulario con inputs para nombre, precio y descripción
- ✅ Validación de campos obligatorios
- ✅ Mensajes dinámicos de éxito/error
- ✅ Prevención de datos vacíos o inválidos

### TASK 3: Manipulación Dinámica del DOM
- ✅ Creación dinámica de elementos `<li>`
- ✅ Botones "Eliminar" y "Editar" en cada producto
- ✅ Uso de `appendChild()` para agregar elementos
- ✅ Uso de `removeChild()` para eliminar elementos
- ✅ Renderizado actualizado de la lista

### TASK 4: Persistencia en Local Storage
- ✅ Guardado automático de datos con `localStorage.setItem()`
- ✅ Carga automática de datos con `localStorage.getItem()`
- ✅ Persistencia entre sesiones
- ✅ Recuperación de datos al recargar la página

### TASK 5: Integración con Fetch API
- ✅ Operación GET: Obtener productos del servidor
- ✅ Operación POST: Crear nuevos productos en servidor
- ✅ Operación PUT: Actualizar productos en servidor
- ✅ Operación DELETE: Eliminar productos del servidor
- ✅ Manejo con `async/await` y `try...catch`
- ✅ Logs detallados de cada operación

### TASK 6: Validaciones y Pruebas
- ✅ Validación de entrada de datos
- ✅ Manejo de errores en Local Storage
- ✅ Manejo de errores en API
- ✅ Mensajes informativos en consola
- ✅ Estadísticas en vivo

---

## 🔍 Ejemplos de Uso en Consola

### Ver todos los productos en Local Storage
```javascript
console.log(JSON.parse(localStorage.getItem('productos_app')));
```

### Ver productos en memoria
```javascript
console.log(productos);
```

### Agregar un producto manualmente
```javascript
productos.push({
    id: Date.now(),
    nombre: "Mi Producto",
    precio: 99.99,
    descripcion: "Descripción del producto",
    fechaCreacion: new Date().toLocaleDateString()
});
guardarProductosEnLocalStorage();
renderizarProductos();
```

### Sincronizar con API
```javascript
syncWithAPI();
```

---

## 📊 Operaciones CRUD con API

### GET - Obtener productos
```javascript
fetch('http://localhost:3000/productos')
    .then(res => res.json())
    .then(data => console.log(data));
```

### POST - Crear producto
```javascript
fetch('http://localhost:3000/productos', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
        nombre: "Nuevo Producto",
        precio: 99.99,
        descripcion: "Descripción"
    })
})
.then(res => res.json())
.then(data => console.log('Creado:', data));
```

### PUT - Actualizar producto
```javascript
fetch('http://localhost:3000/productos/1', {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
        nombre: "Producto Actualizado",
        precio: 149.99
    })
})
.then(res => res.json())
.then(data => console.log('Actualizado:', data));
```

### DELETE - Eliminar producto
```javascript
fetch('http://localhost:3000/productos/1', {
    method: 'DELETE'
})
.then(res => console.log('Eliminado'));
```

---

## 🎨 Elementos Visuales

### Mensajes Dinámicos
- ✅ **Verde** (Éxito): Operación completada correctamente
- ❌ **Rojo** (Error): Operación fallida o validación rechazada
- ℹ️ **Azul** (Info): Información general

### Estadísticas
- Total de Productos
- Valor Total (suma de precios)
- Promedio de Precio

---

## 🔧 Configuración Personalizada

### Cambiar URL de la API

Edita la variable `API_URL` en `app.js`:

```javascript
const API_URL = 'http://localhost:3000/productos'; // Cambia aquí
```

### Cambiar clave de Local Storage

Edita la variable `STORAGE_KEY` en `app.js`:

```javascript
const STORAGE_KEY = 'productos_app'; // Cambia aquí
```

---

## 🐛 Solución de Problemas

### "Error de sincronización" o "Connection refused"
- Asegúrate de que JSON Server esté corriendo
- Verifica que el puerto 3000 esté disponible
- Ejecuta: `json-server --watch db.json`

### Los datos no se guardan
- Verifica que Local Storage esté habilitado en el navegador
- Revisa la consola (F12) para mensajes de error
- Intenta borrar los datos y cargar de nuevo

### Los botones no funcionan
- Abre la consola (F12) y busca errores
- Verifica que `app.js` esté correctamente enlazado en el HTML
- Recarga la página (Ctrl + F5)

---

## 📚 Conceptos JavaScript Utilizados

- **ES6+**: `const`, `let`, arrow functions, template literals
- **DOM**: `createElement()`, `appendChild()`, `removeChild()`, `getElementById()`
- **Local Storage**: `setItem()`, `getItem()`
- **Fetch API**: `async/await`, `try...catch`
- **Array Methods**: `map()`, `filter()`, `find()`, `forEach()`
- **JSON**: `stringify()`, `parse()`
- **Event Handling**: `onclick`, `onsubmit`

---

## 🎓 Aprendizaje

Esta aplicación demuestra:

1. **Manipulación del DOM**: Creación y eliminación de elementos dinámicos
2. **Almacenamiento de datos**: Persistencia con Local Storage
3. **Comunicación con servidores**: Fetch API con CRUD
4. **Validación de datos**: Control de entrada de usuario
5. **Manejo de errores**: Try-catch y mensajes informativos
6. **Interfaz responsiva**: CSS moderno con gradientes y animaciones
7. **Buenas prácticas**: Código comentado y organizado

---

## 📝 Notas Importantes

- Los datos se guardan en Local Storage automáticamente
- La sincronización con API es manual (botón "Sincronizar")
- Los productos tienen IDs únicos basados en timestamp
- Se recomienda usar JSON Server para pruebas locales
- El navegador debe tener JavaScript habilitado

---

## 🤝 Contribuciones

Si encuentras mejoras o correcciones, siéntete libre de adaptarlas.

---

## 📄 Licencia

Proyecto educativo de demostración.

---

## 🎉 ¡Gracias por usar el Gestor de Productos!

Para más ayuda, revisa la consola (F12) donde se registran todos los eventos y operaciones.

**Feliz codificación! 🚀**
