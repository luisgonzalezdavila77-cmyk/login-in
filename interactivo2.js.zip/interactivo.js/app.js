// ========================================
// CONFIGURACIÓN INICIAL Y VARIABLES GLOBALES
// ========================================

// URL de la API (puedes cambiarla según tu servidor)
// Para JSON Server local: http://localhost:3000/productos
const API_URL = 'http://localhost:3000/productos';

// Arreglo global para almacenar los productos
let productos = [];

// Clave para Local Storage
const STORAGE_KEY = 'productos_app';

// ========================================
// INICIALIZACIÓN DEL PROGRAMA
// ========================================
document.addEventListener('DOMContentLoaded', () => {
    console.log('=== APLICACIÓN DE GESTOR DE PRODUCTOS INICIADA ===');
    
    // Cargar productos desde Local Storage
    cargarProductosDelLocalStorage();
    
    // Renderizar productos en el DOM
    renderizarProductos();
    
    // Mostrar información inicial
    console.log('📦 Productos cargados:', productos);
    console.log('💾 Local Storage:', JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]'));
});

// ========================================
// TASK 2: CAPTURA E INTERACCIÓN CON EL USUARIO
// ========================================

/**
 * Maneja el envío del formulario
 * @param {Event} event - Evento del formulario
 */
function handleFormSubmit(event) {
    event.preventDefault();
    console.log('📝 Formulario enviado...');
    
    // Obtener valores del formulario desde el DOM
    const nombre = document.getElementById('productName').value.trim();
    const precio = parseFloat(document.getElementById('productPrice').value);
    const descripcion = document.getElementById('productDescription').value.trim();
    
    // VALIDACIÓN: Verificar que los campos obligatorios no estén vacíos
    if (!nombre || nombre === '') {
        mostrarMensaje('El nombre del producto es obligatorio.', 'error');
        console.error('❌ Validación fallida: Nombre vacío');
        return;
    }
    
    // VALIDACIÓN: Verificar que el precio sea un número válido
    if (isNaN(precio) || precio < 0) {
        mostrarMensaje('El precio debe ser un número positivo.', 'error');
        console.error('❌ Validación fallida: Precio inválido');
        return;
    }
    
    // VALIDACIÓN: Verificar que el precio no sea cero
    if (precio === 0) {
        mostrarMensaje('El precio debe ser mayor a 0.', 'error');
        console.error('❌ Validación fallida: Precio es cero');
        return;
    }
    
    // Crear objeto del producto
    const nuevoProducto = {
        id: Date.now(), // ID único basado en timestamp
        nombre: nombre,
        precio: precio,
        descripcion: descripcion || 'Sin descripción',
        fechaCreacion: new Date().toLocaleDateString()
    };
    
    // Agregar producto al arreglo global
    productos.push(nuevoProducto);
    console.log('✅ Producto agregado:', nuevoProducto);
    
    // Guardar en Local Storage
    guardarProductosEnLocalStorage();
    
    // Mostrar mensaje de éxito
    mostrarMensaje(`✅ Producto "${nombre}" agregado exitosamente.`, 'success');
    
    // Renderizar la lista actualizada
    renderizarProductos();
    
    // Limpiar formulario
    document.getElementById('productForm').reset();
    
    // Registrar en consola el estado actual
    console.log('📊 Estado actual del Local Storage:', JSON.parse(localStorage.getItem(STORAGE_KEY)));
}

// ========================================
// TASK 3: MANIPULACIÓN DINÁMICA DEL DOM
// ========================================

/**
 * Renderiza dinámicamente la lista de productos en el DOM
 * Utiliza appendChild() para agregar elementos
 */
function renderizarProductos() {
    console.log('🔄 Renderizando productos...');
    
    const productsList = document.getElementById('productsList');
    
    // Limpiar la lista actual
    productsList.innerHTML = '';
    
    // Verificar si hay productos
    if (productos.length === 0) {
        productsList.innerHTML = '<li class="empty-message">No hay productos. ¡Agrega uno para comenzar! 🚀</li>';
        actualizarEstadisticas();
        return;
    }
    
    // Recorrer cada producto y crear un elemento <li> dinámicamente
    productos.forEach((producto) => {
        // Crear elemento <li>
        const li = document.createElement('li');
        li.className = 'product-item';
        li.id = `producto-${producto.id}`;
        
        // Crear contenedor de información del producto
        const infoDiv = document.createElement('div');
        infoDiv.className = 'product-info';
        
        // Nombre del producto
        const nombreElement = document.createElement('div');
        nombreElement.className = 'product-name';
        nombreElement.textContent = `${producto.nombre}`;
        infoDiv.appendChild(nombreElement);
        
        // Detalles del producto
        const detallesDiv = document.createElement('div');
        detallesDiv.className = 'product-details';
        
        // Precio
        const precioElement = document.createElement('div');
        precioElement.className = 'product-price';
        precioElement.textContent = `💰 Precio: $${producto.precio.toFixed(2)}`;
        detallesDiv.appendChild(precioElement);
        
        // Descripción
        const descripcionElement = document.createElement('div');
        descripcionElement.className = 'product-description';
        descripcionElement.textContent = `📝 ${producto.descripcion}`;
        detallesDiv.appendChild(descripcionElement);
        
        // Fecha de creación
        const fechaElement = document.createElement('div');
        fechaElement.className = 'product-description';
        fechaElement.textContent = `📅 Creado: ${producto.fechaCreacion}`;
        detallesDiv.appendChild(fechaElement);
        
        infoDiv.appendChild(detallesDiv);
        
        // Crear contenedor de acciones
        const actionsDiv = document.createElement('div');
        actionsDiv.className = 'product-actions';
        
        // Botón Editar
        const btnEditar = document.createElement('button');
        btnEditar.className = 'btn-editar';
        btnEditar.textContent = '✏️ Editar';
        btnEditar.onclick = () => editarProducto(producto.id);
        actionsDiv.appendChild(btnEditar);
        
        // Botón Eliminar
        const btnEliminar = document.createElement('button');
        btnEliminar.className = 'btn-eliminar';
        btnEliminar.textContent = '🗑️ Eliminar';
        btnEliminar.onclick = () => eliminarProducto(producto.id);
        actionsDiv.appendChild(btnEliminar);
        
        // Agregar información y acciones al elemento <li> usando appendChild()
        li.appendChild(infoDiv);
        li.appendChild(actionsDiv);
        
        // Agregar el elemento <li> a la lista usando appendChild()
        productsList.appendChild(li);
    });
    
    // Actualizar estadísticas
    actualizarEstadisticas();
    console.log(`✅ ${productos.length} producto(s) renderizado(s)`);
}

/**
 * Elimina un producto del DOM y del arreglo
 * Utiliza removeChild() para remover elementos
 * @param {number} id - ID del producto a eliminar
 */
function eliminarProducto(id) {
    console.log(`🗑️ Eliminando producto con ID: ${id}`);
    
    // Confirmar eliminación
    if (!confirm('¿Estás seguro de que deseas eliminar este producto?')) {
        console.log('❌ Eliminación cancelada');
        return;
    }
    
    // Encontrar el índice del producto
    const indice = productos.findIndex(p => p.id === id);
    
    if (indice === -1) {
        console.error('❌ Producto no encontrado');
        mostrarMensaje('Producto no encontrado.', 'error');
        return;
    }
    
    // Obtener el nombre del producto antes de eliminarlo
    const nombreProducto = productos[indice].nombre;
    
    // Eliminar del arreglo
    productos.splice(indice, 1);
    console.log(`✅ Producto eliminado del arreglo. Quedan ${productos.length} productos.`);
    
    // Guardar en Local Storage
    guardarProductosEnLocalStorage();
    
    // Eliminar del DOM usando removeChild()
    const li = document.getElementById(`producto-${id}`);
    if (li) {
        li.parentNode.removeChild(li);
        console.log('✅ Elemento removido del DOM');
    }
    
    // Mostrar mensaje de éxito
    mostrarMensaje(`✅ Producto "${nombreProducto}" eliminado exitosamente.`, 'success');
    
    // Renderizar nuevamente
    renderizarProductos();
    
    // Registrar estado
    console.log('📊 Estado actual del Local Storage:', JSON.parse(localStorage.getItem(STORAGE_KEY)));
}

/**
 * Edita un producto existente
 * @param {number} id - ID del producto a editar
 */
function editarProducto(id) {
    console.log(`✏️ Editando producto con ID: ${id}`);
    
    // Encontrar el producto
    const producto = productos.find(p => p.id === id);
    
    if (!producto) {
        console.error('❌ Producto no encontrado');
        mostrarMensaje('Producto no encontrado.', 'error');
        return;
    }
    
    // Solicitar nuevos valores
    const nuevoNombre = prompt('Nombre del producto:', producto.nombre);
    if (nuevoNombre === null) return; // Cancelado
    
    const nuevoPrecio = prompt('Precio del producto:', producto.precio);
    if (nuevoPrecio === null) return; // Cancelado
    
    const nuevaDescripcion = prompt('Descripción:', producto.descripcion);
    if (nuevaDescripcion === null) return; // Cancelado
    
    // Validar nuevos valores
    if (!nuevoNombre.trim()) {
        mostrarMensaje('El nombre no puede estar vacío.', 'error');
        return;
    }
    
    const precioNumerico = parseFloat(nuevoPrecio);
    if (isNaN(precioNumerico) || precioNumerico <= 0) {
        mostrarMensaje('El precio debe ser un número válido mayor a 0.', 'error');
        return;
    }
    
    // Actualizar producto
    producto.nombre = nuevoNombre.trim();
    producto.precio = precioNumerico;
    producto.descripcion = nuevaDescripcion.trim() || 'Sin descripción';
    
    console.log('✅ Producto actualizado:', producto);
    
    // Guardar cambios
    guardarProductosEnLocalStorage();
    mostrarMensaje(`✅ Producto "${producto.nombre}" actualizado exitosamente.`, 'success');
    
    // Renderizar
    renderizarProductos();
}

// ========================================
// TASK 4: PERSISTENCIA EN LOCAL STORAGE
// ========================================

/**
 * Guarda los productos en Local Storage
 * Utiliza localStorage.setItem()
 */
function guardarProductosEnLocalStorage() {
    try {
        const productosJSON = JSON.stringify(productos);
        localStorage.setItem(STORAGE_KEY, productosJSON);
        console.log('💾 Datos guardados en Local Storage');
        console.log('📦 Total de productos guardados:', productos.length);
    } catch (error) {
        console.error('❌ Error al guardar en Local Storage:', error);
        mostrarMensaje('Error al guardar datos en Local Storage.', 'error');
    }
}

/**
 * Carga los productos desde Local Storage
 * Utiliza localStorage.getItem()
 * Se ejecuta automáticamente al recargar la página
 */
function cargarProductosDelLocalStorage() {
    try {
        const productosJSON = localStorage.getItem(STORAGE_KEY);
        
        if (productosJSON) {
            productos = JSON.parse(productosJSON);
            console.log('✅ Productos cargados desde Local Storage:', productos);
        } else {
            console.log('ℹ️ No hay datos previos en Local Storage');
            productos = [];
        }
    } catch (error) {
        console.error('❌ Error al cargar desde Local Storage:', error);
        productos = [];
    }
}

// ========================================
// TASK 5: INTEGRACIÓN CON FETCH API
// ========================================

/**
 * Sincroniza los datos con la API
 * Implementa operaciones GET, POST, PUT, DELETE
 * Utiliza async/await y try...catch
 */
async function syncWithAPI() {
    console.log('🔄 Iniciando sincronización con API...');
    mostrarMensaje('⏳ Sincronizando con API...', 'info');
    
    try {
        // OPERACIÓN GET: Obtener la lista de elementos del servidor
        console.log('📥 GET: Obteniendo productos del servidor...');
        const responseGet = await fetch(API_URL);
        
        if (!responseGet.ok) {
            throw new Error(`Error GET: ${responseGet.statusText}`);
        }
        
        const productosDelServidor = await responseGet.json();
        console.log('✅ Productos obtenidos del servidor:', productosDelServidor);
        
        // OPERACIÓN POST: Agregar nuevos productos al servidor
        console.log('📤 POST: Enviando productos al servidor...');
        
        // Recorrer los productos locales y enviar los que no tienen ID de servidor
        for (const producto of productos) {
            // Verificar si el producto ya existe en el servidor
            const existeEnServidor = productosDelServidor.some(p => p.id === producto.id);
            
            if (!existeEnServidor) {
                try {
                    const responsePost = await fetch(API_URL, {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                        },
                        body: JSON.stringify(producto)
                    });
                    
                    if (responsePost.ok) {
                        const nuevoProducto = await responsePost.json();
                        console.log(`✅ Producto creado en servidor:`, nuevoProducto);
                    }
                } catch (error) {
                    console.error(`❌ Error al crear producto "${producto.nombre}":`, error);
                }
            }
        }
        
        // Mostrar mensaje de éxito
        mostrarMensaje(`✅ Sincronización completada. ${productos.length} producto(s) sincronizado(s).`, 'success');
        console.log('🎉 Sincronización finalizada exitosamente');
        
    } catch (error) {
        console.error('❌ Error durante la sincronización:', error);
        mostrarMensaje(`❌ Error de sincronización: ${error.message}. Verifica que el servidor esté corriendo en ${API_URL}`, 'error');
    }
}

/**
 * Elimina un producto del servidor
 * Implementa operación DELETE
 * @param {number} id - ID del producto
 */
async function eliminarDelServidor(id) {
    console.log(`🗑️ DELETE: Eliminando producto ${id} del servidor...`);
    
    try {
        const response = await fetch(`${API_URL}/${id}`, {
            method: 'DELETE'
        });
        
        if (response.ok) {
            console.log(`✅ Producto ${id} eliminado del servidor`);
        } else {
            throw new Error(`Error: ${response.statusText}`);
        }
    } catch (error) {
        console.error(`❌ Error al eliminar del servidor:`, error);
    }
}

/**
 * Actualiza un producto en el servidor
 * Implementa operación PUT
 * @param {number} id - ID del producto
 * @param {object} productoActualizado - Datos actualizados
 */
async function actualizarEnServidor(id, productoActualizado) {
    console.log(`✏️ PUT: Actualizando producto ${id} en el servidor...`);
    
    try {
        const response = await fetch(`${API_URL}/${id}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(productoActualizado)
        });
        
        if (response.ok) {
            const productoActualizado = await response.json();
            console.log(`✅ Producto actualizado en servidor:`, productoActualizado);
        } else {
            throw new Error(`Error: ${response.statusText}`);
        }
    } catch (error) {
        console.error(`❌ Error al actualizar en servidor:`, error);
    }
}

// ========================================
// FUNCIONES AUXILIARES
// ========================================

/**
 * Muestra mensajes dinámicos en el DOM
 * @param {string} mensaje - Texto del mensaje
 * @param {string} tipo - Tipo: 'success', 'error', 'info'
 */
function mostrarMensaje(mensaje, tipo = 'info') {
    const container = document.getElementById('messageContainer');
    
    // Determinar clase según tipo
    let claseCSS = `message-${tipo}`;
    
    // Establecer el contenido
    container.textContent = mensaje;
    container.className = `message-container show ${claseCSS}`;
    
    // Log en consola
    if (tipo === 'error') {
        console.error(mensaje);
    } else if (tipo === 'success') {
        console.log(mensaje);
    } else {
        console.info(mensaje);
    }
    
    // Ocultar después de 4 segundos (opcional)
    setTimeout(() => {
        container.classList.remove('show');
    }, 4000);
}

/**
 * Actualiza las estadísticas mostradas en el DOM
 */
function actualizarEstadisticas() {
    const totalProductos = productos.length;
    const totalValor = productos.reduce((suma, p) => suma + p.precio, 0);
    const promedioPrecio = totalProductos > 0 ? totalValor / totalProductos : 0;
    
    // Actualizar elementos del DOM
    document.getElementById('totalProducts').textContent = totalProductos;
    document.getElementById('totalValue').textContent = `$${totalValor.toFixed(2)}`;
    document.getElementById('averagePrice').textContent = `$${promedioPrecio.toFixed(2)}`;
    
    console.log(`📊 Estadísticas actualizadas - Total: ${totalProductos}, Valor: $${totalValor.toFixed(2)}`);
}

/**
 * Limpia todos los productos
 */
function clearAllProducts() {
    if (!confirm('⚠️ ¿Estás seguro de que deseas eliminar TODOS los productos? Esta acción no se puede deshacer.')) {
        console.log('❌ Operación cancelada');
        return;
    }
    
    console.log('🗑️ Eliminando todos los productos...');
    
    productos = [];
    guardarProductosEnLocalStorage();
    renderizarProductos();
    mostrarMensaje('✅ Todos los productos han sido eliminados.', 'success');
    console.log('✅ Local Storage limpiado');
}

// ========================================
// LOGS INFORMATIVOS
// ========================================
console.log('📖 INSTRUCCIONES PARA USAR LA API:');
console.log('1. Instala JSON Server: npm install -g json-server');
console.log('2. Crea un archivo db.json con: { "productos": [] }');
console.log('3. Inicia el servidor: json-server --watch db.json');
console.log('4. La API estará en: http://localhost:3000/productos');
console.log('5. Usa el botón "Sincronizar con API" para sincronizar datos');
