# 🔍 Guía de Verificación - Comandos para Consola

Esta guía te proporciona comandos que puedes copiar y pegar directamente en la consola del navegador para verificar cada funcionalidad.

---

## 🚀 Cómo usar esta guía

1. Abre `index.html` en tu navegador
2. Abre la consola (F12 → Console)
3. Copia y pega cada comando
4. Verifica que el resultado sea el esperado

---

## 🧪 Comandos de Prueba

### 1. Verificar que app.js está cargado

```javascript
typeof productos !== 'undefined'
```

**Resultado esperado:** `true`

---

### 2. Ver todos los productos en memoria

```javascript
console.table(productos)
```

**Resultado esperado:** Una tabla con todos los productos

---

### 3. Ver contenido de Local Storage

```javascript
JSON.parse(localStorage.getItem('productos_app'))
```

**Resultado esperado:** Un arreglo con los productos guardados

---

### 4. Contar productos en Local Storage

```javascript
JSON.parse(localStorage.getItem('productos_app')).length
```

**Resultado esperado:** El número de productos (0 si está vacío)

---

### 5. Agregar un producto manualmente desde consola

```javascript
const nuevoProducto = {
    id: Date.now(),
    nombre: "Producto de Prueba",
    precio: 99.99,
    descripcion: "Creado desde consola",
    fechaCreacion: new Date().toLocaleDateString()
};

productos.push(nuevoProducto);
guardarProductosEnLocalStorage();
renderizarProductos();

console.log("✅ Producto agregado:", nuevoProducto);
```

**Resultado esperado:**
- El producto aparece en la lista
- Se guarda en Local Storage
- Se muestra en la consola

---

### 6. Editar un producto (cambiar precio)

```javascript
// Supongamos que el primer producto existe
if (productos.length > 0) {
    productos[0].precio = 199.99;
    guardarProductosEnLocalStorage();
    renderizarProductos();
    console.log("✅ Producto actualizado:", productos[0]);
} else {
    console.log("❌ No hay productos para editar");
}
```

**Resultado esperado:**
- El precio se actualiza en el DOM
- Los cambios se guardan en Local Storage

---

### 7. Eliminar un producto por ID

```javascript
// Eliminar el primer producto
if (productos.length > 0) {
    const idProducto = productos[0].id;
    const indice = productos.findIndex(p => p.id === idProducto);
    
    if (indice !== -1) {
        const nombreEliminado = productos[indice].nombre;
        productos.splice(indice, 1);
        guardarProductosEnLocalStorage();
        renderizarProductos();
        console.log(`✅ "${nombreEliminado}" eliminado`);
    }
} else {
    console.log("❌ No hay productos para eliminar");
}
```

**Resultado esperado:**
- El producto desaparece de la lista
- Se elimina de Local Storage

---

### 8. Calcular estadísticas

```javascript
const totalProductos = productos.length;
const totalValor = productos.reduce((suma, p) => suma + p.precio, 0);
const promedioPrecio = totalProductos > 0 ? totalValor / totalProductos : 0;

console.log(`
📊 ESTADÍSTICAS:
- Total de productos: ${totalProductos}
- Valor total: $${totalValor.toFixed(2)}
- Promedio de precio: $${promedioPrecio.toFixed(2)}
`);
```

**Resultado esperado:**
```
📊 ESTADÍSTICAS:
- Total de productos: 3
- Valor total: $519.97
- Promedio de precio: $173.32
```

---

### 9. Limpiar todo (Local Storage y memoria)

```javascript
// ⚠️ ADVERTENCIA: Esto eliminará todos los datos
if (confirm('⚠️ ¿Estás seguro de que deseas eliminar TODOS los productos?')) {
    productos = [];
    guardarProductosEnLocalStorage();
    renderizarProductos();
    console.log("✅ Todos los datos han sido eliminados");
} else {
    console.log("❌ Operación cancelada");
}
```

**Resultado esperado:**
- Todos los productos se eliminan
- Local Storage queda vacío

---

### 10. Sincronizar con API

```javascript
syncWithAPI();
```

**Resultado esperado:**
```
🔄 Iniciando sincronización con API...
📥 GET: Obteniendo productos del servidor...
✅ Productos obtenidos del servidor: [...]
📤 POST: Enviando productos al servidor...
✅ Sincronización completada...
```

---

## 🔌 Pruebas de Fetch API (si tienes JSON Server corriendo)

### 1. GET - Obtener productos del servidor

```javascript
fetch('http://localhost:3000/productos')
    .then(res => res.json())
    .then(data => {
        console.log("✅ GET: Productos del servidor:", data);
        console.table(data);
    })
    .catch(error => console.error("❌ Error:", error));
```

**Resultado esperado:** Array de productos del servidor

---

### 2. POST - Crear un producto en servidor

```javascript
fetch('http://localhost:3000/productos', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
        nombre: "Producto Prueba API",
        precio: 299.99,
        descripcion: "Creado desde Fetch API",
        fechaCreacion: new Date().toLocaleDateString()
    })
})
.then(res => res.json())
.then(data => console.log("✅ POST: Producto creado:", data))
.catch(error => console.error("❌ Error:", error));
```

**Resultado esperado:** 
```
✅ POST: Producto creado: {
  nombre: "Producto Prueba API",
  precio: 299.99,
  ...
  id: 4
}
```

---

### 3. PUT - Actualizar un producto en servidor

```javascript
// Cambiar el producto con ID 1
fetch('http://localhost:3000/productos/1', {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
        nombre: "Laptop Actualizada",
        precio: 1199.99,
        descripcion: "Actualizada desde API",
        fechaCreacion: "03/06/2026"
    })
})
.then(res => res.json())
.then(data => console.log("✅ PUT: Producto actualizado:", data))
.catch(error => console.error("❌ Error:", error));
```

**Resultado esperado:**
```
✅ PUT: Producto actualizado: {
  nombre: "Laptop Actualizada",
  precio: 1199.99,
  ...
  id: 1
}
```

---

### 4. DELETE - Eliminar un producto del servidor

```javascript
// Eliminar el producto con ID 4
fetch('http://localhost:3000/productos/4', {
    method: 'DELETE'
})
.then(res => {
    if (res.ok) {
        console.log("✅ DELETE: Producto eliminado del servidor (ID: 4)");
    } else {
        console.log("❌ Error:", res.statusText);
    }
})
.catch(error => console.error("❌ Error:", error));
```

**Resultado esperado:**
```
✅ DELETE: Producto eliminado del servidor (ID: 4)
```

---

## 📋 Pruebas de Validación

### 1. Validar nombre vacío

```javascript
const nombre = "";
const precio = 99.99;

if (!nombre || nombre.trim() === "") {
    console.error("❌ Validación fallida: Nombre vacío");
} else {
    console.log("✅ Nombre válido");
}
```

**Resultado esperado:**
```
❌ Validación fallida: Nombre vacío
```

---

### 2. Validar precio

```javascript
const precio = "ABC";

if (isNaN(precio) || precio <= 0) {
    console.error("❌ Validación fallida: Precio inválido");
} else {
    console.log("✅ Precio válido");
}
```

**Resultado esperado:**
```
❌ Validación fallida: Precio inválido
```

---

### 3. Validar precio negativo

```javascript
const precio = -50;

if (precio <= 0) {
    console.error("❌ Validación fallida: Precio debe ser positivo");
} else {
    console.log("✅ Precio válido");
}
```

**Resultado esperado:**
```
❌ Validación fallida: Precio debe ser positivo
```

---

## 🎯 Prueba Completa (Copiar y Pegar Todo)

Ejecuta este script completo para una prueba exhaustiva:

```javascript
console.clear();
console.log("🧪 INICIANDO PRUEBAS COMPLETAS...\n");

// 1. Verificar app.js
console.log("1️⃣ Verificando app.js...");
console.log(typeof productos !== 'undefined' ? "✅ app.js cargado" : "❌ app.js no cargado");

// 2. Verificar productos en memoria
console.log("\n2️⃣ Productos en memoria:");
console.log(`Total: ${productos.length}`);

// 3. Verificar Local Storage
console.log("\n3️⃣ Local Storage:");
const datosLocal = JSON.parse(localStorage.getItem('productos_app') || '[]');
console.log(`Total guardado: ${datosLocal.length}`);

// 4. Verificar funciones
console.log("\n4️⃣ Verificando funciones:");
console.log(typeof renderizarProductos === 'function' ? "✅ renderizarProductos" : "❌ renderizarProductos");
console.log(typeof guardarProductosEnLocalStorage === 'function' ? "✅ guardarProductosEnLocalStorage" : "❌ guardarProductosEnLocalStorage");
console.log(typeof syncWithAPI === 'function' ? "✅ syncWithAPI" : "❌ syncWithAPI");
console.log(typeof mostrarMensaje === 'function' ? "✅ mostrarMensaje" : "❌ mostrarMensaje");

// 5. Estadísticas
console.log("\n5️⃣ Estadísticas:");
const total = productos.reduce((sum, p) => sum + p.precio, 0);
console.log(`Productos: ${productos.length}`);
console.log(`Valor Total: $${total.toFixed(2)}`);
console.log(`Promedio: $${(total / (productos.length || 1)).toFixed(2)}`);

console.log("\n🎉 PRUEBAS COMPLETADAS");
```

**Resultado esperado:**
```
🧪 INICIANDO PRUEBAS COMPLETAS...

1️⃣ Verificando app.js...
✅ app.js cargado

2️⃣ Productos en memoria:
Total: 3

3️⃣ Local Storage:
Total guardado: 3

4️⃣ Verificando funciones:
✅ renderizarProductos
✅ guardarProductosEnLocalStorage
✅ syncWithAPI
✅ mostrarMensaje

5️⃣ Estadísticas:
Productos: 3
Valor Total: $519.97
Promedio: $173.32

🎉 PRUEBAS COMPLETADAS
```

---

## 🛠️ Solución de Problemas

### Error: "productos is not defined"

**Causa:** `app.js` no se está cargando correctamente

**Solución:**
```javascript
// Verifica que app.js exista
// Recarga la página (Ctrl + F5)
// Verifica la consola para errores de carga
```

---

### Error: "localStorage is not defined"

**Causa:** Estás usando Firefox en modo privado o tienes restricciones de storage

**Solución:**
```javascript
// Abre en navegación normal (no privada)
// O desactiva las restricciones de storage
```

---

### Error: "fetch: Failed to fetch"

**Causa:** JSON Server no está corriendo o la URL es incorrecta

**Solución:**
```bash
# Inicia JSON Server en otra terminal
json-server --watch db.json

# Verifica que esté en http://localhost:3000
```

---

## 📊 Resumen de Comandos Útiles

| Comando | Propósito |
|---------|-----------|
| `console.table(productos)` | Ver productos como tabla |
| `JSON.parse(localStorage.getItem('productos_app'))` | Ver Local Storage |
| `renderizarProductos()` | Actualizar DOM |
| `guardarProductosEnLocalStorage()` | Guardar datos |
| `syncWithAPI()` | Sincronizar con servidor |
| `mostrarMensaje('Texto', 'success')` | Mostrar mensaje |
| `actualizarEstadisticas()` | Actualizar estadísticas |

---

## 🎓 Conceptos Validados

✅ DOM Manipulation (appendChild, removeChild)
✅ Local Storage (setItem, getItem)
✅ Fetch API (GET, POST, PUT, DELETE)
✅ Async/Await (async functions)
✅ Try/Catch (error handling)
✅ Array Methods (map, filter, find, reduce)
✅ JSON (stringify, parse)
✅ Event Handling (onclick, onsubmit)
✅ Validaciones de datos
✅ Mensajes dinámicos

---

## 🎉 ¡Todos los comandos están listos!

Copia y pega en la consola para verificar tu aplicación. ¡Feliz desarrollo! 🚀

---

**Última actualización:** 03/06/2026
**Versión:** 1.0.0
