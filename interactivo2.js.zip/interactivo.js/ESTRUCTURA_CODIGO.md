# 📐 Estructura del Código - Guía Detallada

Este documento explica la estructura y organización del código en `app.js` e `index.html`.

---

## 📁 Organización de Archivos

```
proyecto/
├── index.html                    # Interfaz HTML con estilos CSS
├── app.js                        # Lógica de JavaScript (TODO EL CÓDIGO)
├── db.json                       # Base de datos para JSON Server
├── README.md                     # Documentación principal
├── INSTRUCCIONES_PRUEBA.md       # Guía de pruebas
├── VERIFICACION_CONSOLA.md       # Comandos para consola
├── ESTRUCTURA_CODIGO.md          # Este archivo
└── sistema_interactivo.js        # Archivo anterior (no necesario)
```

---

## 🏗️ Estructura de `index.html`

### Secciones principales:

#### 1. **Head** (líneas 1-80)
- Meta tags (charset, viewport)
- Título del documento
- Estilos CSS completos (incrustados)

#### 2. **Body** (líneas 81-300)

**a) Estructura HTML:**
```html
<div class="container">
    ├── <div class="header">              <!-- Encabezado -->
    └── <div class="content">             <!-- Contenido principal -->
        ├── <div class="form-section">    <!-- Formulario -->
        ├── <div class="stats-section">   <!-- Estadísticas -->
        └── <div class="list-section">    <!-- Lista de productos -->
```

**b) Formulario (`form-section`):**
- ID: `productForm`
- Campos:
  - `productName` (text)
  - `productPrice` (number)
  - `productDescription` (text)
- Botones:
  - Agregar producto (submit)
  - Sincronizar con API
  - Limpiar todo

**c) Contenedor de mensajes:**
- ID: `messageContainer`
- Classes: `message-success`, `message-error`, `message-info`

**d) Estadísticas (`stats-section`):**
- `totalProducts` (cantidad)
- `totalValue` (suma de precios)
- `averagePrice` (promedio)

**e) Lista de productos:**
- ID: `productsList` (elemento `<ul>`)
- Renderizada dinámicamente desde JavaScript

#### 3. **Script** (línea 300)
```html
<script src="app.js"></script>
```

---

## 🧠 Estructura de `app.js`

### 📊 Diagrama General

```
app.js
├── 1. CONFIGURACIÓN INICIAL
│   ├── const API_URL
│   ├── let productos []
│   └── const STORAGE_KEY
│
├── 2. INICIALIZACIÓN (DOMContentLoaded)
│   ├── cargarProductosDelLocalStorage()
│   ├── renderizarProductos()
│   └── console.log()
│
├── 3. TASK 2: CAPTURA DE DATOS
│   └── handleFormSubmit()
│       ├── Obtener valores del DOM
│       ├── Validar datos
│       ├── Crear objeto producto
│       ├── Agregar al arreglo
│       ├── Guardar en Local Storage
│       └── Renderizar
│
├── 4. TASK 3: MANIPULACIÓN DEL DOM
│   ├── renderizarProductos()
│   ├── eliminarProducto()
│   └── editarProducto()
│
├── 5. TASK 4: LOCAL STORAGE
│   ├── guardarProductosEnLocalStorage()
│   └── cargarProductosDelLocalStorage()
│
├── 6. TASK 5: FETCH API
│   ├── syncWithAPI()          (GET + POST)
│   ├── eliminarDelServidor()  (DELETE)
│   └── actualizarEnServidor() (PUT)
│
├── 7. FUNCIONES AUXILIARES
│   ├── mostrarMensaje()
│   ├── actualizarEstadisticas()
│   └── clearAllProducts()
│
└── 8. LOGS INFORMATIVOS
    └── console.log()
```

---

## 🔍 Análisis Detallado de Funciones

### **Sección 1: Configuración Inicial**

```javascript
const API_URL = 'http://localhost:3000/productos';
let productos = [];
const STORAGE_KEY = 'productos_app';
```

**Propósito:**
- `API_URL`: URL del servidor (JSON Server)
- `productos`: Arreglo global que almacena todos los productos en memoria
- `STORAGE_KEY`: Clave única para Local Storage

**Modificables:**
- Cambiar `API_URL` si tu servidor está en otro puerto
- Cambiar `STORAGE_KEY` si necesitas múltiples espacios de almacenamiento

---

### **Sección 2: Inicialización (DOMContentLoaded)**

```javascript
document.addEventListener('DOMContentLoaded', () => {
    cargarProductosDelLocalStorage();  // Recuperar datos guardados
    renderizarProductos();              // Mostrar en DOM
    console.log(...);                   // Logs informativos
});
```

**Flujo:**
1. Espera a que el DOM esté completamente cargado
2. Carga productos desde Local Storage
3. Renderiza la interfaz
4. Registra logs

---

### **Sección 3: TASK 2 - handleFormSubmit()**

```javascript
function handleFormSubmit(event) {
    // 1. Prevenir recarga de página
    event.preventDefault();
    
    // 2. CAPTURAR datos del DOM
    const nombre = document.getElementById('productName').value.trim();
    const precio = parseFloat(document.getElementById('productPrice').value);
    const descripcion = document.getElementById('productDescription').value.trim();
    
    // 3. VALIDAR
    if (!nombre) {
        mostrarMensaje('El nombre es obligatorio.', 'error');
        return;
    }
    if (isNaN(precio) || precio <= 0) {
        mostrarMensaje('El precio debe ser válido.', 'error');
        return;
    }
    
    // 4. CREAR objeto
    const nuevoProducto = {
        id: Date.now(),
        nombre: nombre,
        precio: precio,
        descripcion: descripcion || 'Sin descripción',
        fechaCreacion: new Date().toLocaleDateString()
    };
    
    // 5. AGREGAR al arreglo
    productos.push(nuevoProducto);
    
    // 6. GUARDAR en Local Storage
    guardarProductosEnLocalStorage();
    
    // 7. RENDERIZAR
    renderizarProductos();
    
    // 8. LIMPIAR formulario
    document.getElementById('productForm').reset();
}
```

**Validaciones implementadas:**
- Nombre no vacío
- Precio es número válido
- Precio es positivo

---

### **Sección 3a: renderizarProductos()**

```javascript
function renderizarProductos() {
    const productsList = document.getElementById('productsList');
    
    // Limpiar lista anterior
    productsList.innerHTML = '';
    
    // Si no hay productos
    if (productos.length === 0) {
        productsList.innerHTML = '<li class="empty-message">...</li>';
        return;
    }
    
    // Recorrer cada producto
    productos.forEach((producto) => {
        // Crear elementos HTML
        const li = document.createElement('li');
        li.className = 'product-item';
        li.id = `producto-${producto.id}`;
        
        // ... Crear contenedor de información
        // ... Crear contenedor de acciones (botones)
        
        // Agregar al DOM (appendChild)
        productsList.appendChild(li);
    });
    
    actualizarEstadisticas();
}
```

**Tecnología DOM:**
- `createElement()`: Crea nuevos elementos
- `appendChild()`: Agrega elementos al DOM
- `forEach()`: Itera sobre cada producto

---

### **Sección 3b: eliminarProducto()**

```javascript
function eliminarProducto(id) {
    // 1. Confirmar eliminación
    if (!confirm('¿Estás seguro?')) return;
    
    // 2. Encontrar índice en arreglo
    const indice = productos.findIndex(p => p.id === id);
    
    // 3. Eliminar del arreglo
    productos.splice(indice, 1);
    
    // 4. Guardar cambios
    guardarProductosEnLocalStorage();
    
    // 5. Eliminar del DOM (removeChild)
    const li = document.getElementById(`producto-${id}`);
    li.parentNode.removeChild(li);
    
    // 6. Renderizar nuevamente
    renderizarProductos();
}
```

**Tecnología DOM:**
- `removeChild()`: Elimina elementos del DOM

---

### **Sección 3c: editarProducto()**

```javascript
function editarProducto(id) {
    // 1. Encontrar producto
    const producto = productos.find(p => p.id === id);
    
    // 2. Solicitar nuevos valores
    const nuevoNombre = prompt('Nombre:', producto.nombre);
    const nuevoPrecio = prompt('Precio:', producto.precio);
    
    // 3. Validar
    if (isNaN(nuevoPrecio) || nuevoPrecio <= 0) {
        mostrarMensaje('Precio inválido', 'error');
        return;
    }
    
    // 4. Actualizar objeto
    producto.nombre = nuevoNombre;
    producto.precio = parseFloat(nuevoPrecio);
    
    // 5. Guardar y renderizar
    guardarProductosEnLocalStorage();
    renderizarProductos();
}
```

---

### **Sección 4: TASK 4 - Local Storage**

#### **guardarProductosEnLocalStorage()**

```javascript
function guardarProductosEnLocalStorage() {
    try {
        // Convertir arreglo a JSON
        const productosJSON = JSON.stringify(productos);
        
        // Guardar con clave
        localStorage.setItem(STORAGE_KEY, productosJSON);
        
        console.log('💾 Datos guardados en Local Storage');
    } catch (error) {
        console.error('❌ Error al guardar:', error);
    }
}
```

**Proceso:**
1. `JSON.stringify()`: Convierte arreglo a texto JSON
2. `localStorage.setItem()`: Guarda con una clave
3. `try...catch`: Maneja errores (espacios llenos, etc.)

---

#### **cargarProductosDelLocalStorage()**

```javascript
function cargarProductosDelLocalStorage() {
    try {
        // Obtener datos con clave
        const productosJSON = localStorage.getItem(STORAGE_KEY);
        
        if (productosJSON) {
            // Convertir JSON a arreglo
            productos = JSON.parse(productosJSON);
        } else {
            productos = [];
        }
    } catch (error) {
        console.error('❌ Error al cargar:', error);
        productos = [];
    }
}
```

**Proceso:**
1. `localStorage.getItem()`: Obtiene datos con clave
2. `JSON.parse()`: Convierte JSON a arreglo
3. `try...catch`: Maneja errores (datos corruptos, etc.)
4. Se ejecuta automáticamente al cargar la página

---

### **Sección 5: TASK 5 - Fetch API**

#### **syncWithAPI()**

```javascript
async function syncWithAPI() {
    try {
        // 1. GET - Obtener productos del servidor
        const responseGet = await fetch(API_URL);
        const productosDelServidor = await responseGet.json();
        
        // 2. POST - Crear productos nuevos
        for (const producto of productos) {
            const existeEnServidor = productosDelServidor.some(
                p => p.id === producto.id
            );
            
            if (!existeEnServidor) {
                const responsePost = await fetch(API_URL, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(producto)
                });
                
                const nuevoProducto = await responsePost.json();
            }
        }
        
        mostrarMensaje('✅ Sincronización completada', 'success');
    } catch (error) {
        console.error('❌ Error:', error);
        mostrarMensaje('❌ Error de sincronización', 'error');
    }
}
```

**Características:**
- `async/await`: Espera respuestas del servidor
- `try...catch`: Maneja errores de red
- `fetch()`: Realiza solicitudes HTTP
- GET: Obtiene lista del servidor
- POST: Crea productos nuevos

---

#### **Operaciones PUT y DELETE**

```javascript
// DELETE - Eliminar del servidor
async function eliminarDelServidor(id) {
    const response = await fetch(`${API_URL}/${id}`, {
        method: 'DELETE'
    });
}

// PUT - Actualizar en servidor
async function actualizarEnServidor(id, productoActualizado) {
    const response = await fetch(`${API_URL}/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(productoActualizado)
    });
}
```

---

### **Sección 6: Funciones Auxiliares**

#### **mostrarMensaje()**

```javascript
function mostrarMensaje(mensaje, tipo = 'info') {
    const container = document.getElementById('messageContainer');
    
    // Establecer clase según tipo
    container.className = `message-container show message-${tipo}`;
    container.textContent = mensaje;
    
    // Log en consola
    console.log(mensaje);
    
    // Ocultar después de 4 segundos
    setTimeout(() => {
        container.classList.remove('show');
    }, 4000);
}
```

**Tipos de mensajes:**
- `success` (verde)
- `error` (rojo)
- `info` (azul)

---

#### **actualizarEstadisticas()**

```javascript
function actualizarEstadisticas() {
    const totalProductos = productos.length;
    const totalValor = productos.reduce((suma, p) => suma + p.precio, 0);
    const promedioPrecio = totalProductos > 0 ? totalValor / totalProductos : 0;
    
    document.getElementById('totalProducts').textContent = totalProductos;
    document.getElementById('totalValue').textContent = `$${totalValor.toFixed(2)}`;
    document.getElementById('averagePrice').textContent = `$${promedioPrecio.toFixed(2)}`;
}
```

**Cálculos:**
- Total: Cantidad de productos
- Valor: Suma de precios
- Promedio: Valor / Cantidad

---

## 📊 Flujo de Datos

### Flujo 1: Agregar Producto

```
Usuario escribe en formulario
        ↓
handleFormSubmit() recibe evento
        ↓
Valida datos
        ↓
Crea objeto producto
        ↓
productos.push() → Agrega a arreglo global
        ↓
guardarProductosEnLocalStorage() → Local Storage
        ↓
renderizarProductos() → Actualiza DOM
        ↓
mostrarMensaje() → Muestra confirmación
```

---

### Flujo 2: Eliminar Producto

```
Usuario hace clic en "Eliminar"
        ↓
eliminarProducto(id)
        ↓
Confirma eliminación
        ↓
Encuentra índice en arreglo
        ↓
productos.splice() → Elimina del arreglo
        ↓
guardarProductosDelLocalStorage() → Actualiza Local Storage
        ↓
li.parentNode.removeChild() → Elimina del DOM
        ↓
renderizarProductos() → Re-renderiza lista
```

---

### Flujo 3: Sincronizar con API

```
Usuario hace clic en "Sincronizar"
        ↓
syncWithAPI() → async function
        ↓
fetch(GET) → Obtiene productos del servidor
        ↓
Compara con productos locales
        ↓
fetch(POST) → Crea productos nuevos en servidor
        ↓
mostrarMensaje() → Confirma sincronización
        ↓
console.log() → Registra operación
```

---

## 🎯 Mapeo de Funciones a TASKS

| TASK | Funciones Principales | Tecnologías |
|------|----------------------|-------------|
| 2 | `handleFormSubmit()` | DOM, validación |
| 3 | `renderizarProductos()`, `eliminarProducto()`, `editarProducto()` | appendChild(), removeChild() |
| 4 | `guardarProductosEnLocalStorage()`, `cargarProductosDelLocalStorage()` | localStorage.setItem(), getItem() |
| 5 | `syncWithAPI()`, `eliminarDelServidor()`, `actualizarEnServidor()` | Fetch API, async/await |
| 6 | Todas las anteriores | Integración completa |

---

## 🧩 Estructura de Objeto Producto

```javascript
{
    id: 1717334400000,           // Timestamp único
    nombre: "Laptop Gaming",      // String obligatorio
    precio: 1299.99,             // Number positivo
    descripcion: "Alta calidad",  // String (opcional)
    fechaCreacion: "03/06/2026"   // String fecha
}
```

---

## 💾 Estructura en Local Storage

**Clave:** `productos_app`

**Valor:** JSON stringify de arreglo
```json
[
    {
        "id": 1717334400000,
        "nombre": "Laptop",
        "precio": 1299.99,
        "descripcion": "Gaming",
        "fechaCreacion": "03/06/2026"
    },
    ...
]
```

---

## 🔗 Estructura de Solicitud Fetch

### GET
```javascript
fetch('http://localhost:3000/productos')
// Obtiene todos los productos
```

### POST
```javascript
fetch('http://localhost:3000/productos', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(producto)
})
// Crea nuevo producto
```

### PUT
```javascript
fetch('http://localhost:3000/productos/1', {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(productoActualizado)
})
// Actualiza producto con ID 1
```

### DELETE
```javascript
fetch('http://localhost:3000/productos/1', {
    method: 'DELETE'
})
// Elimina producto con ID 1
```

---

## 📚 Array Methods Utilizados

| Método | Función | Ejemplo |
|--------|---------|---------|
| `push()` | Agregar al final | `productos.push(nuevo)` |
| `splice()` | Eliminar elemento | `productos.splice(indice, 1)` |
| `find()` | Buscar un elemento | `productos.find(p => p.id === id)` |
| `findIndex()` | Buscar índice | `productos.findIndex(p => p.id === id)` |
| `forEach()` | Iterar | `productos.forEach(p => {...})` |
| `map()` | Transformar | `productos.map(p => p.nombre)` |
| `filter()` | Filtrar | `productos.filter(p => p.precio > 100)` |
| `reduce()` | Agregar | `productos.reduce((sum, p) => sum + p.precio, 0)` |
| `some()` | Verificar existencia | `productos.some(p => p.id === id)` |

---

## 🎓 Conceptos Clave Implementados

✅ **ES6+**
- `const` y `let`
- Arrow functions `() => {}`
- Template literals `` `${variable}` ``
- Destructuring
- Spread operator

✅ **DOM API**
- `getElementById()`
- `createElement()`
- `appendChild()`
- `removeChild()`
- `addEventListener()`

✅ **Async Programming**
- `async/await`
- `Promises` (implícitas en fetch)
- `try...catch`

✅ **Storage**
- `localStorage.setItem()`
- `localStorage.getItem()`
- `JSON.stringify()`
- `JSON.parse()`

✅ **Networking**
- `Fetch API`
- HTTP Methods (GET, POST, PUT, DELETE)
- Headers
- JSON body

---

## 🔐 Validaciones Implementadas

1. **Nombre:**
   - No puede estar vacío
   - Se aplica `.trim()` para eliminar espacios

2. **Precio:**
   - Debe ser un número (validado con `isNaN()`)
   - Debe ser positivo (`> 0`)
   - Permite decimales

3. **ID:**
   - Único (basado en `Date.now()`)
   - Nunca se duplica

4. **Sincronización:**
   - Verifica si producto existe antes de crear (POST)
   - Maneja errores de conexión (try...catch)

---

## 🎉 Conclusión

La estructura está optimizada para:
- **Legibilidad**: Código comentado y bien organizado
- **Mantenibilidad**: Funciones específicas por TASK
- **Escalabilidad**: Fácil agregar nuevas funciones
- **Robustez**: Validaciones y manejo de errores
- **Performance**: Sin operaciones innecesarias

---

**Última actualización:** 03/06/2026  
**Versión:** 1.0.0
