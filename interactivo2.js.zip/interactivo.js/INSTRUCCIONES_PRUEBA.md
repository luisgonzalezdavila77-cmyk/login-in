# 🧪 Guía Completa de Pruebas por TASK

Esta guía te ayudará a verificar que cada TASK funciona correctamente.

---

## 📋 Pre-requisitos

1. Abre `index.html` en tu navegador
2. Abre la consola del navegador con **F12**
3. Navega a la pestaña **Console** para ver los logs

---

## ✅ TASK 2: Captura e Interacción con el Usuario

### Objetivo
Validar que el formulario captura correctamente nombre, precio y descripción, y que se validan los campos.

### Prueba 1: Agregar producto válido
**Pasos:**
1. Completa el formulario con:
   - Nombre: "Laptop Gaming"
   - Precio: "1299.99"
   - Descripción: "Laptop para juegos"
2. Haz clic en "✅ Agregar Producto"

**Resultado esperado:**
- En consola ves:
  ```
  📝 Formulario enviado...
  ✅ Producto agregado: { id: ..., nombre: "Laptop Gaming", ... }
  ✅ Producto "Laptop Gaming" agregado exitosamente.
  ```
- Un mensaje verde aparece en el DOM
- El producto aparece en la lista

**Captura:**
```
Console Output:
📝 Formulario enviado...
✅ Producto agregado: {
  id: 1717334400000,
  nombre: "Laptop Gaming",
  precio: 1299.99,
  descripción: "Laptop para juegos",
  fechaCreacion: "03/06/2026"
}
✅ Producto "Laptop Gaming" agregado exitosamente.
```

---

### Prueba 2: Validar nombre vacío
**Pasos:**
1. Deja el campo "Nombre" vacío
2. Completa Precio: "99.99"
3. Haz clic en "✅ Agregar Producto"

**Resultado esperado:**
- En consola ves:
  ```
  ❌ Validación fallida: Nombre vacío
  ```
- Un mensaje rojo aparece: "El nombre del producto es obligatorio."
- El producto NO se agrega

**Captura:**
```
Console Output:
❌ Validación fallida: Nombre vacío
Error: El nombre del producto es obligatorio.
```

---

### Prueba 3: Validar precio inválido
**Pasos:**
1. Nombre: "Mouse"
2. Precio: "ABC" (texto en lugar de número)
3. Haz clic en "✅ Agregar Producto"

**Resultado esperado:**
- En consola ves:
  ```
  ❌ Validación fallida: Precio inválido
  ```
- Mensaje rojo: "El precio debe ser un número positivo."
- El producto NO se agrega

**Captura:**
```
Console Output:
❌ Validación fallida: Precio inválido
Error: El precio debe ser un número positivo.
```

---

### Prueba 4: Validar precio negativo
**Pasos:**
1. Nombre: "Teclado"
2. Precio: "-50"
3. Haz clic en "✅ Agregar Producto"

**Resultado esperado:**
- Mensaje rojo: "El precio debe ser un número positivo."

---

## ✅ TASK 3: Manipulación Dinámica del DOM

### Objetivo
Validar que los elementos se crean dinámicamente en el DOM y que los botones funcionan correctamente.

### Prueba 1: Crear elemento `<li>` dinámicamente
**Pasos:**
1. Agrega un producto: "Monitor" - $299.99
2. Abre DevTools (F12) → Pestaña "Elements"
3. Busca el elemento `<li>` con clase `product-item`

**Resultado esperado:**
- Ves un `<li>` con:
  ```html
  <li class="product-item" id="producto-1717334400000">
    <div class="product-info">
      <div class="product-name">Monitor</div>
      <div class="product-details">
        <div class="product-price">💰 Precio: $299.99</div>
        ...
      </div>
    </div>
    <div class="product-actions">
      <button class="btn-editar">✏️ Editar</button>
      <button class="btn-eliminar">🗑️ Eliminar</button>
    </div>
  </li>
  ```

**Captura:**
```
En DevTools (Elements):
<li class="product-item" id="producto-1717334400000">
  <div class="product-info">
    ...
  </div>
</li>
```

---

### Prueba 2: Botón Eliminar funciona
**Pasos:**
1. Agrega un producto: "Mouse" - $29.99
2. Haz clic en el botón "🗑️ Eliminar"
3. Confirma la eliminación
4. Abre DevTools → Elements

**Resultado esperado:**
- En consola ves:
  ```
  🗑️ Eliminando producto con ID: ...
  ✅ Producto eliminado del arreglo. Quedan 1 productos.
  ✅ Elemento removido del DOM
  ✅ Producto "Mouse" eliminado exitosamente.
  ```
- El elemento `<li>` se elimina del DOM
- El mensaje verde aparece

**Captura:**
```
Console Output:
🗑️ Eliminando producto con ID: 1717334400001
✅ Producto eliminado del arreglo. Quedan 1 productos.
✅ Elemento removido del DOM
✅ Producto "Mouse" eliminado exitosamente.
```

---

### Prueba 3: Botón Editar funciona
**Pasos:**
1. Agrega un producto: "SSD" - $199.99
2. Haz clic en "✏️ Editar"
3. Cambia el nombre a "SSD Samsung" en el prompt
4. Haz clic OK

**Resultado esperado:**
- En consola ves:
  ```
  ✏️ Editando producto con ID: ...
  ✅ Producto actualizado: { nombre: "SSD Samsung", ... }
  ✅ Producto "SSD Samsung" actualizado exitosamente.
  ```
- El nombre se actualiza en el DOM

**Captura:**
```
Console Output:
✏️ Editando producto con ID: 1717334400002
✅ Producto actualizado: {
  id: 1717334400002,
  nombre: "SSD Samsung",
  precio: 199.99,
  ...
}
✅ Producto "SSD Samsung" actualizado exitosamente.
```

---

## ✅ TASK 4: Persistencia en Local Storage

### Objetivo
Validar que los datos se guardan en Local Storage y persisten entre sesiones.

### Prueba 1: Datos se guardan en Local Storage
**Pasos:**
1. Agrega 2-3 productos
2. Abre DevTools (F12) → Pestaña "Application" (o "Storage")
3. En el menú izquierdo, selecciona "Local Storage" → tu sitio

**Resultado esperado:**
- Ves una clave llamada `productos_app`
- El valor es un JSON con todos los productos:
  ```json
  [
    {
      "id": 1717334400000,
      "nombre": "Laptop Gaming",
      "precio": 1299.99,
      "descripcion": "Laptop para juegos",
      "fechaCreacion": "03/06/2026"
    },
    {
      "id": 1717334400001,
      "nombre": "Monitor",
      "precio": 299.99,
      "descripcion": "Monitor 4K",
      "fechaCreacion": "03/06/2026"
    }
  ]
  ```

**Captura:**
```
DevTools → Application → Local Storage
Key: productos_app
Value: [
  {"id":1717334400000,"nombre":"Laptop Gaming","precio":1299.99,...},
  {"id":1717334400001,"nombre":"Monitor","precio":299.99,...}
]
```

---

### Prueba 2: Datos persisten al recargar
**Pasos:**
1. Agrega 2 productos: "GPU" - $599.99 y "RAM" - $199.99
2. Abre la consola
3. Recarga la página (F5 o Ctrl+R)

**Resultado esperado:**
- La página se recarga
- Los 2 productos siguen apareciendo en la lista
- En consola ves:
  ```
  === APLICACIÓN DE GESTOR DE PRODUCTOS INICIADA ===
  ✅ Productos cargados desde Local Storage: [...]
  📦 Productos cargados: [...]
  ```

**Captura:**
```
Console Output después de recarga:
=== APLICACIÓN DE GESTOR DE PRODUCTOS INICIADA ===
✅ Productos cargados desde Local Storage: [
  {id: 1717334400003, nombre: "GPU", precio: 599.99, ...},
  {id: 1717334400004, nombre: "RAM", precio: 199.99, ...}
]
```

---

### Prueba 3: Actualizar en Local Storage
**Pasos:**
1. Edita un producto existente
2. Abre DevTools → Application → Local Storage
3. Verifica que el JSON se actualizó

**Resultado esperado:**
- El producto editado tiene los nuevos valores en Local Storage

---

### Prueba 4: Ver contenido de Local Storage en consola
**Pasos:**
1. Abre la consola
2. Ejecuta:
   ```javascript
   console.log(JSON.parse(localStorage.getItem('productos_app')));
   ```

**Resultado esperado:**
- Se imprime el arreglo de todos los productos

**Captura:**
```
Console Input:
> JSON.parse(localStorage.getItem('productos_app'))

Console Output:
(2) [{…}, {…}]
0: {id: 1717334400000, nombre: "Laptop Gaming", precio: 1299.99, ...}
1: {id: 1717334400001, nombre: "Monitor", precio: 299.99, ...}
```

---

## ✅ TASK 5: Integración con Fetch API

### Objetivo
Validar que la aplicación se comunica correctamente con la API usando operaciones CRUD.

### Pre-requisito: Inicia JSON Server
```bash
# En otra terminal o ventana CMD
json-server --watch db.json
```

Deberías ver:
```
  \{^_^}/ hi!

  Loading db.json
  Done

  Resources
  http://localhost:3000/productos

  Home
  http://localhost:3000
```

---

### Prueba 1: GET - Obtener productos del servidor
**Pasos:**
1. Asegúrate de que JSON Server esté corriendo
2. Abre la consola
3. Haz clic en "🔄 Sincronizar con API"

**Resultado esperado:**
- En consola ves:
  ```
  🔄 Iniciando sincronización con API...
  📥 GET: Obteniendo productos del servidor...
  ✅ Productos obtenidos del servidor: [...]
  ```

**Captura:**
```
Console Output:
🔄 Iniciando sincronización con API...
📥 GET: Obteniendo productos del servidor...
✅ Productos obtenidos del servidor: [
  {id: 1, nombre: "Laptop Dell", precio: 899.99, ...},
  {id: 2, nombre: "Mouse Inalámbrico", precio: 29.99, ...}
]
```

---

### Prueba 2: POST - Crear producto en servidor
**Pasos:**
1. Agrega un producto localmente: "Webcam" - $89.99
2. Haz clic en "🔄 Sincronizar con API"
3. Verifica DevTools → Network (tab)

**Resultado esperado:**
- En consola ves:
  ```
  📤 POST: Enviando productos al servidor...
  ✅ Producto creado en servidor: { id: 4, nombre: "Webcam", ... }
  ✅ Sincronización completada...
  ```
- En db.json se agrega el nuevo producto

**Captura:**
```
Console Output:
📤 POST: Enviando productos al servidor...
✅ Producto creado en servidor: {
  id: 1717334400005,
  nombre: "Webcam",
  precio: 89.99,
  ...
}
✅ Sincronización completada. 1 producto(s) sincronizado(s).
```

---

### Prueba 3: Verificar en db.json
**Pasos:**
1. Abre el archivo `db.json`
2. Verifica que los productos estén allí

**Resultado esperado:**
```json
{
  "productos": [
    {
      "id": 1,
      "nombre": "Laptop Dell",
      "precio": 899.99,
      ...
    },
    {
      "id": 1717334400005,
      "nombre": "Webcam",
      "precio": 89.99,
      ...
    }
  ]
}
```

---

### Prueba 4: Manejo de errores - API no disponible
**Pasos:**
1. Detén JSON Server (Ctrl+C)
2. Intenta sincronizar

**Resultado esperado:**
- Mensaje rojo en el DOM:
  ```
  ❌ Error de sincronización: ... Verifica que el servidor esté corriendo
  ```
- En consola:
  ```
  ❌ Error durante la sincronización: ...
  ```

**Captura:**
```
Console Output:
❌ Error durante la sincronización: 
Failed to fetch (o similar)
Error: Connection refused
```

---

## ✅ TASK 6: Validaciones y Pruebas Finales

### Prueba 1: Flujo completo de integración

**Pasos:**
1. Inicia JSON Server
2. Abre `index.html`
3. Agrega 3 productos:
   - "Monitor 32\"" - $349.99 - "Full HD"
   - "Auriculares" - $149.99 - "Wireless"
   - "Mousepad" - $19.99 - "RGB"

**Verificaciones:**

✅ **DOM**: Los 3 productos aparecen en la lista
```
Producto 1: Monitor 32" - $349.99
Producto 2: Auriculares - $149.99
Producto 3: Mousepad - $19.99
```

✅ **Local Storage**: Los datos están guardados
```javascript
JSON.parse(localStorage.getItem('productos_app')).length === 3
// true
```

✅ **Estadísticas**: Se calculan correctamente
```
Total: 3 productos
Valor Total: $519.97
Promedio: $173.32
```

✅ **Consola**: Mensajes claros y organizados
```
✅ Producto agregado: {...}
✅ Producto agregado: {...}
✅ Producto agregado: {...}
📊 Estadísticas actualizadas...
```

---

### Prueba 2: Sincronizar con API

**Pasos:**
1. Con los 3 productos creados, haz clic en "🔄 Sincronizar con API"
2. Verifica el resultado

**Resultado esperado:**
- Consola muestra:
  ```
  ✅ Productos obtenidos del servidor: [...]
  📤 POST: Enviando productos al servidor...
  ✅ Producto creado en servidor: {...}
  ✅ Producto creado en servidor: {...}
  ✅ Producto creado en servidor: {...}
  ✅ Sincronización completada. 3 producto(s) sincronizado(s).
  ```

- db.json contiene los productos

---

### Prueba 3: Eliminar y verificar sincronización

**Pasos:**
1. Elimina un producto
2. Sincroniza nuevamente

**Verificaciones:**
✅ El producto se elimina del DOM
✅ Se elimina de Local Storage
✅ Se actualiza en la consola

---

### Prueba 4: Editar y sincronizar

**Pasos:**
1. Edita un producto (cambia precio o nombre)
2. Sincroniza con API

**Verificaciones:**
✅ El cambio se refleja en el DOM
✅ Se guarda en Local Storage
✅ Se envía al servidor

---

## 📊 Captura Final Completa

Aquí está el ejemplo de cómo debería verse todo funcionando:

### 1. Interfaz del navegador
```
┌─────────────────────────────────────────────┐
│ 📦 Gestor de Productos                       │
├─────────────────────────────────────────────┤
│                                              │
│ ✅ Producto "Monitor" agregado exitosamente │
│                                              │
│ Nombre:  [Monitor         ]                 │
│ Precio:  [349.99          ]                 │
│ Descrip: [Full HD Monitor ]                 │
│                                              │
│ [✅ Agregar] [🔄 Sincronizar] [🗑️ Limpiar] │
│                                              │
│ 📊 Total: 3 | Valor: $519.97 | Prom: $173  │
│                                              │
│ 📋 PRODUCTOS                                 │
│ • Monitor 32" - $349.99 [✏️] [🗑️]           │
│ • Auriculares - $149.99 [✏️] [🗑️]           │
│ • Mousepad - $19.99 [✏️] [🗑️]              │
│                                              │
└─────────────────────────────────────────────┘
```

### 2. Consola del navegador
```
=== APLICACIÓN DE GESTOR DE PRODUCTOS INICIADA ===
✅ Productos cargados desde Local Storage: [...]
📦 Productos cargados: Array(3)
💾 Local Storage: Array(3)

📝 Formulario enviado...
✅ Producto agregado: {
  id: 1717334400000,
  nombre: "Monitor 32\"",
  precio: 349.99,
  ...
}
✅ Producto "Monitor 32\"" agregado exitosamente.
🔄 Renderizando productos...
✅ 1 producto(s) renderizado(s)
📊 Estadísticas actualizadas...

🔄 Iniciando sincronización con API...
📥 GET: Obteniendo productos del servidor...
✅ Productos obtenidos del servidor: Array(3)
📤 POST: Enviando productos al servidor...
✅ Producto creado en servidor: {...}
✅ Sincronización completada. 3 producto(s) sincronizado(s).
```

### 3. Local Storage
```
Key: productos_app
Value: [
  {
    "id": 1717334400000,
    "nombre": "Monitor 32\"",
    "precio": 349.99,
    "descripcion": "Full HD Monitor",
    "fechaCreacion": "03/06/2026"
  },
  {
    "id": 1717334400001,
    "nombre": "Auriculares",
    "precio": 149.99,
    "descripcion": "Wireless",
    "fechaCreacion": "03/06/2026"
  },
  {
    "id": 1717334400002,
    "nombre": "Mousepad",
    "precio": 19.99,
    "descripcion": "RGB",
    "fechaCreacion": "03/06/2026"
  }
]
```

---

## ✨ Checklist Final

- [ ] ✅ TASK 2: Captura y validación funcionan
- [ ] ✅ TASK 3: DOM se manipula correctamente (crear, editar, eliminar)
- [ ] ✅ TASK 4: Local Storage persiste datos entre sesiones
- [ ] ✅ TASK 5: Fetch API sincroniza con servidor (GET, POST, PUT, DELETE)
- [ ] ✅ TASK 6: Todo funciona en conjunto sin errores

---

## 🎉 ¡Si todas las pruebas pasan, tu aplicación está lista para producción!

Para cualquier problema, revisa:
1. La consola del navegador (F12)
2. Las instrucciones específicas del TASK fallido
3. Verifica que JSON Server esté corriendo si pruebas sincronización

**Feliz desarrollo! 🚀**
